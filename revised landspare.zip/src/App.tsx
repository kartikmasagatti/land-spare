import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ExecutiveOverview } from './components/ExecutiveOverview';
import { GISMapViewer } from './components/GISMapViewer';
import { AIPolicyAdvisor } from './components/AIPolicyAdvisor';
import { PolicyImpactML } from './components/PolicyImpactML';
import { StateComparisonDashboard } from './components/StateComparisonDashboard';
import { DataCatalog } from './components/DataCatalog';
import { ResearchPortal } from './components/ResearchPortal';
import { OpenAPIPlayground } from './components/OpenAPIPlayground';
import { CitizenKhasraSearch } from './components/CitizenKhasraSearch';
import { UserPersona, LanguageCode, CadastralParcel } from './types/landspare';
import { MOCK_CADASTRAL_PARCELS, MOCK_DATASETS } from './data/mockLandData';
import { Search, X, Award, ShieldCheck, ExternalLink, Terminal, Sparkles } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [activePersona, setActivePersona] = useState<UserPersona>('policymaker');
  const [currentLang, setCurrentLang] = useState<LanguageCode>('en');
  const [selectedStateForGIS, setSelectedStateForGIS] = useState<string>('KA');

  // Quick Command Palette / Search Modal (Cmd+K)
  const [isQuickSearchOpen, setIsQuickSearchOpen] = useState<boolean>(false);
  const [quickSearchTerm, setQuickSearchTerm] = useState<string>('');

  // Keyboard shortcut listener for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsQuickSearchOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        setIsQuickSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleStateSelectForGIS = (stateCode: string) => {
    setSelectedStateForGIS(stateCode);
    setCurrentTab('gis');
  };

  const handleNavigateToDataset = (_datasetId: string) => {
    setCurrentTab('datasets');
  };

  const handleInspectParcelInGIS = (_parcel: CadastralParcel) => {
    setCurrentTab('gis');
  };

  // Filter items in quick search
  const quickFilteredParcels = MOCK_CADASTRAL_PARCELS.filter(
    (p) =>
      p.khasraNumber.toLowerCase().includes(quickSearchTerm.toLowerCase()) ||
      p.ulpin.toLowerCase().includes(quickSearchTerm.toLowerCase()) ||
      p.primaryOwner.toLowerCase().includes(quickSearchTerm.toLowerCase())
  );

  const quickFilteredDatasets = MOCK_DATASETS.filter(
    (d) =>
      d.title.toLowerCase().includes(quickSearchTerm.toLowerCase()) ||
      d.tags.some((t) => t.toLowerCase().includes(quickSearchTerm.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Institutional Top Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        activePersona={activePersona}
        setActivePersona={setActivePersona}
        currentLang={currentLang}
        setCurrentLang={setCurrentLang}
        onOpenQuickSearch={() => setIsQuickSearchOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'overview' && (
          <ExecutiveOverview
            onNavigate={(tab) => setCurrentTab(tab)}
            currentLang={currentLang}
            activePersona={activePersona}
            onSelectStateForGIS={handleStateSelectForGIS}
          />
        )}

        {currentTab === 'gis' && (
          <GISMapViewer
            currentLang={currentLang}
            selectedStateCode={selectedStateForGIS}
          />
        )}

        {currentTab === 'ai-advisor' && (
          <AIPolicyAdvisor currentLang={currentLang} />
        )}

        {currentTab === 'policy-ml' && (
          <PolicyImpactML currentLang={currentLang} />
        )}

        {currentTab === 'state-matrix' && (
          <StateComparisonDashboard
            currentLang={currentLang}
            onInspectInGIS={handleStateSelectForGIS}
          />
        )}

        {currentTab === 'datasets' && (
          <DataCatalog
            currentLang={currentLang}
            onNavigateToApi={() => setCurrentTab('api')}
          />
        )}

        {currentTab === 'research' && (
          <ResearchPortal
            currentLang={currentLang}
            onNavigateToDataset={handleNavigateToDataset}
          />
        )}

        {currentTab === 'api' && (
          <OpenAPIPlayground currentLang={currentLang} />
        )}

        {currentTab === 'citizen' && (
          <CitizenKhasraSearch
            currentLang={currentLang}
            onInspectInGIS={handleInspectParcelInGIS}
          />
        )}
      </main>

      {/* Command Palette Quick Search Modal */}
      {isQuickSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-3 border-b border-slate-800 flex items-center space-x-2">
              <Search className="w-5 h-5 text-emerald-400" />
              <input
                type="text"
                autoFocus
                placeholder="Type to search Khasra, Bhu-Aadhaar, datasets, or policies..."
                value={quickSearchTerm}
                onChange={(e) => setQuickSearchTerm(e.target.value)}
                className="w-full bg-transparent border-none text-white text-sm focus:outline-none placeholder-slate-500"
              />
              <button
                onClick={() => setIsQuickSearchOpen(false)}
                className="p-1 rounded bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 max-h-96 overflow-y-auto space-y-3 text-xs">
              {/* Quick Navigation Targets */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                  Quick Navigation
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => {
                      setCurrentTab('gis');
                      setIsQuickSearchOpen(false);
                    }}
                    className="p-2 rounded bg-slate-950 hover:bg-slate-800 text-left text-slate-300 flex items-center justify-between"
                  >
                    <span>GIS Land Cadastre</span>
                    <span className="text-[10px] text-emerald-400">Map</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('ai-advisor');
                      setIsQuickSearchOpen(false);
                    }}
                    className="p-2 rounded bg-slate-950 hover:bg-slate-800 text-left text-slate-300 flex items-center justify-between"
                  >
                    <span>AI Policy Briefs</span>
                    <span className="text-[10px] text-teal-400">Gemini</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('policy-ml');
                      setIsQuickSearchOpen(false);
                    }}
                    className="p-2 rounded bg-slate-950 hover:bg-slate-800 text-left text-slate-300 flex items-center justify-between"
                  >
                    <span>Policy ML Simulator</span>
                    <span className="text-[10px] text-cyan-400">Impact</span>
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTab('datasets');
                      setIsQuickSearchOpen(false);
                    }}
                    className="p-2 rounded bg-slate-950 hover:bg-slate-800 text-left text-slate-300 flex items-center justify-between"
                  >
                    <span>100+ Datasets Catalog</span>
                    <span className="text-[10px] text-amber-400">Open Data</span>
                  </button>
                </div>
              </div>

              {/* Cadastral Parcels Match */}
              {quickFilteredParcels.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-slate-800">
                  <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                    Cadastral Land Parcels
                  </span>
                  {quickFilteredParcels.slice(0, 3).map((parcel) => (
                    <button
                      key={parcel.id}
                      onClick={() => {
                        setCurrentTab('gis');
                        setIsQuickSearchOpen(false);
                      }}
                      className="w-full p-2 rounded-lg bg-slate-950 hover:bg-slate-800/80 text-left flex items-center justify-between group transition-colors"
                    >
                      <div>
                        <div className="font-semibold text-white group-hover:text-emerald-300">
                          {parcel.khasraNumber} ({parcel.ulpin})
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {parcel.primaryOwner} • {parcel.village}, {parcel.district} ({parcel.areaHectares} Ha)
                        </div>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {parcel.landUse}
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {/* Datasets Match */}
              {quickFilteredDatasets.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-slate-800">
                  <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                    Governance Datasets
                  </span>
                  {quickFilteredDatasets.slice(0, 3).map((ds) => (
                    <button
                      key={ds.id}
                      onClick={() => {
                        setCurrentTab('datasets');
                        setIsQuickSearchOpen(false);
                      }}
                      className="w-full p-2 rounded-lg bg-slate-950 hover:bg-slate-800/80 text-left flex items-center justify-between group transition-colors"
                    >
                      <div>
                        <div className="font-semibold text-white group-hover:text-teal-300 line-clamp-1">
                          {ds.title}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {ds.source} • {ds.recordsCount}
                        </div>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                        {ds.category}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
              <span>Press <kbd className="px-1 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-400">ESC</kbd> to exit</span>
              <span className="text-emerald-400">Landspare Fast Index</span>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950/80 py-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center font-black text-white text-sm">
              LS
            </div>
            <div>
              <div className="font-bold text-white flex items-center gap-1.5">
                <span>Landspare</span>
                <span className="text-slate-500">•</span>
                <span className="text-emerald-400">National Land Governance Architecture</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Department of Land Resources (DoLR) • NITI Aayog • Survey Settlement & Land Records
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>DILRMP & SVAMITVA Conforming</span>
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">World Bank LGAF Indicators</span>
            <span className="text-slate-600">•</span>
            <span className="text-teal-400">Powered by Gemini 3.8 & Leaflet GIS</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
