import React from 'react';
import {
  Layers,
  Sparkles,
  Scale,
  Database,
  Search,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  FileCheck2,
  Plane,
  ShieldCheck,
  ChevronRight,
  Landmark,
  Building,
} from 'lucide-react';
import { NATIONAL_SUMMARY_METRICS, MOCK_STATE_METRICS } from '../data/mockLandData';
import { LanguageCode, UserPersona } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface ExecutiveOverviewProps {
  onNavigate: (tab: string) => void;
  currentLang: LanguageCode;
  activePersona: UserPersona;
  onSelectStateForGIS: (stateCode: string) => void;
}

export const ExecutiveOverview: React.FC<ExecutiveOverviewProps> = ({
  onNavigate,
  currentLang,
  activePersona,
  onSelectStateForGIS,
}) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <div className="space-y-6">
      {/* Hero Banner with SIH Context & Mission */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950/80 border border-slate-800 p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium mb-3">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>National Digital Governance Initiative • DILRMP & SVAMITVA Framework</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
            National Digital Platform for Evidence-Based Land Governance
          </h2>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed max-w-3xl">
            {t.tagline}. Integrating <strong className="text-emerald-400 font-semibold">100+ Land Datasets</strong>, Cadastral GIS spatial analytics, automated mutation reconciliation, and <strong className="text-teal-400 font-semibold">Gemini AI Policy Synthesis</strong> to transform presumptive land records into transparent, conclusive property rights.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('gis')}
              className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/60 transition-all hover:scale-[1.02]"
            >
              <Layers className="w-4 h-4" />
              <span>Explore Interactive GIS Cadastre</span>
              <ArrowUpRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={() => onNavigate('ai-advisor')}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-xs sm:text-sm transition-all"
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>AI Policy Brief Generator</span>
            </button>

            <button
              onClick={() => onNavigate('policy-ml')}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-xs sm:text-sm transition-all"
            >
              <Scale className="w-4 h-4 text-teal-400" />
              <span>ML Impact Simulator</span>
            </button>

            <button
              onClick={() => onNavigate('citizen')}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium text-xs sm:text-sm transition-all"
            >
              <Search className="w-4 h-4 text-amber-400" />
              <span>Citizen Khasra Search</span>
            </button>
          </div>
        </div>
      </div>

      {/* National KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>DILRMP Digitization</span>
            <FileCheck2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">
            {NATIONAL_SUMMARY_METRICS.villagesDigitizedPct}%
          </div>
          <div className="mt-1 flex items-center text-[11px] text-emerald-400 font-medium">
            <TrendingUp className="w-3 h-3 mr-1" />
            <span>6.2 Lakh+ Villages Computerized</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-1.5 rounded-full"
              style={{ width: `${NATIONAL_SUMMARY_METRICS.villagesDigitizedPct}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Bhu-Aadhaar (ULPIN)</span>
            <ShieldCheck className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">
            {NATIONAL_SUMMARY_METRICS.bhuAadhaarIssuedCount}
          </div>
          <div className="mt-1 flex items-center text-[11px] text-teal-300 font-medium">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            <span>14-Digit Geo-Coordinate Tagging</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5">
            <div className="bg-gradient-to-r from-teal-500 to-cyan-400 h-1.5 rounded-full" style={{ width: '82%' }} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>SVAMITVA Drone Cards</span>
            <Plane className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">
            {NATIONAL_SUMMARY_METRICS.svamitvaPropertyCardsDistributed}
          </div>
          <div className="mt-1 flex items-center text-[11px] text-cyan-300 font-medium">
            <span>±5cm CORS High-Precision Survey</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5">
            <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 rounded-full" style={{ width: '68%' }} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Civil Court Litigation</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400 tracking-tight">
            {NATIONAL_SUMMARY_METRICS.activeLandLitigationsPanIndia}
          </div>
          <div className="mt-1 flex items-center text-[11px] text-slate-400 font-medium">
            <span>Avg 4.8 Years • Dead Capital ₹4.2L Cr</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5">
            <div className="bg-gradient-to-r from-amber-500 to-rose-500 h-1.5 rounded-full" style={{ width: '58%' }} />
          </div>
        </div>
      </div>

      {/* Two Column Section: State Performance Leaderboard & Innovation Pillars */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: State Land Governance Performance Matrix */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Landmark className="w-4 h-4 text-emerald-400" />
                State Land Records Modernization Benchmark (DILRMP 2026)
              </h3>
              <p className="text-xs text-slate-400">
                Comparative ranking across mutation speed, cadastral vectorization, and tenure security index.
              </p>
            </div>
            <button
              onClick={() => onNavigate('state-matrix')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
            >
              <span>Full Comparison Matrix</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">State & System</th>
                  <th className="py-2.5 px-3">RoR Digitized</th>
                  <th className="py-2.5 px-3">Cadastral Vector</th>
                  <th className="py-2.5 px-3">Avg Mutation</th>
                  <th className="py-2.5 px-3">Disputes / 10k</th>
                  <th className="py-2.5 px-3">Tenure Score</th>
                  <th className="py-2.5 px-3 text-right">GIS Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {MOCK_STATE_METRICS.slice(0, 6).map((st) => (
                  <tr key={st.stateCode} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white">{st.state}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{st.systemName}</div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-medium">
                        {st.computerizedVillagesPct}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-300">{st.cadastralDigitizedPct}%</td>
                    <td className="py-3 px-3">
                      <span className={`font-semibold ${st.averageMutationDays <= 7 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {st.averageMutationDays} Days
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono">{st.disputesPer10kParcels}</td>
                    <td className="py-3 px-3">
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-white">{st.tenureSecurityIndex}</span>
                        <div className="w-12 bg-slate-800 rounded-full h-1.5 hidden sm:block">
                          <div
                            className="bg-emerald-400 h-1.5 rounded-full"
                            style={{ width: `${st.tenureSecurityIndex}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => {
                          onSelectStateForGIS(st.stateCode);
                          onNavigate('gis');
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-600 hover:text-white border border-slate-700 text-slate-300 text-[11px] transition-colors"
                      >
                        Inspect GIS
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Platform Innovations & Live Alerts */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Core Platform Architectural Innovations
            </h3>
            
            <div className="space-y-2.5">
              <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
                <div className="text-xs font-semibold text-emerald-300 flex items-center justify-between">
                  <span>AI Policy Formulation</span>
                  <span className="text-[10px] text-slate-400">Gemini 3.8</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Synthesizes legislative amendments (Registration Act, Land Revenue Code) with targeted economic deliverables.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
                <div className="text-xs font-semibold text-teal-300 flex items-center justify-between">
                  <span>Econometric Policy ML</span>
                  <span className="text-[10px] text-slate-400">Simulations</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Predicts litigation drop, stamp revenue elasticity, and smallholder credit unlock across policy parameter shifts.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
                <div className="text-xs font-semibold text-cyan-300 flex items-center justify-between">
                  <span>Open API for Researchers</span>
                  <span className="text-[10px] text-slate-400">REST / OGC</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Direct programmatic endpoints for universities, World Bank LGAF indicators, and empirical research models.
                </p>
              </div>
            </div>
          </div>

          {/* Real-time Field Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Live Cadastral Stream</h4>
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-start space-x-2 text-slate-300">
                <span className="text-emerald-400 font-mono text-[10px] mt-0.5">14:22</span>
                <div>
                  <p className="font-medium text-white">Hubballi Rural (KA)</p>
                  <p className="text-[11px] text-slate-400">Sy. 842/1A Bhu-Aadhaar ULPIN generated with zero spatial overlap.</p>
                </div>
              </div>
              <div className="flex items-start space-x-2 text-slate-300">
                <span className="text-amber-400 font-mono text-[10px] mt-0.5">12:08</span>
                <div>
                  <p className="font-medium text-white">Kusugal Wetland (KA)</p>
                  <p className="text-[11px] text-slate-400">Sentinel-2 satellite flagged 0.35 Ha buffer zone earthwork anomaly.</p>
                </div>
              </div>
              <div className="flex items-start space-x-2 text-slate-300">
                <span className="text-teal-400 font-mono text-[10px] mt-0.5">09:45</span>
                <div>
                  <p className="font-medium text-white">Pune Taluka (MH)</p>
                  <p className="text-[11px] text-slate-400">E-Haq automated notice dispatched to 4 heirs for digital consensus.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
