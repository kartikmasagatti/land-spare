import React, { useState } from 'react';
import {
  Building2,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Landmark,
  Scale,
  Sparkles,
  Layers,
  Clock,
  Compass
} from 'lucide-react';
import { MOCK_STATE_METRICS } from '../data/mockLandData';
import { StateLandMetric, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface StateComparisonDashboardProps {
  currentLang: LanguageCode;
  onInspectInGIS: (stateCode: string) => void;
}

export const StateComparisonDashboard: React.FC<StateComparisonDashboardProps> = ({
  currentLang,
  onInspectInGIS,
}) => {
  const t = TRANSLATIONS[currentLang];

  const [state1Code, setState1Code] = useState<string>('KA');
  const [state2Code, setState2Code] = useState<string>('MH');
  const [filterRegion, setFilterRegion] = useState<string>('All');

  const state1 = MOCK_STATE_METRICS.find((s) => s.stateCode === state1Code) || MOCK_STATE_METRICS[0];
  const state2 = MOCK_STATE_METRICS.find((s) => s.stateCode === state2Code) || MOCK_STATE_METRICS[1];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold mb-1">
              <Building2 className="w-3.5 h-3.5" />
              <span>Inter-State Comparative Governance Matrix</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {t.nav.stateComparison}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Benchmark digital land administration policies across Indian States (Bhoomi, Dharani, Mahabhumi, Bhulekh, AnyRoR). Analyze mutation turnaround, cadastral georeferencing, and tenure security.
            </p>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Total States Tracked:</span>
            <span className="px-2.5 py-1 rounded bg-slate-800 text-white font-bold border border-slate-700">
              {MOCK_STATE_METRICS.length} Pioneer States
            </span>
          </div>
        </div>
      </div>

      {/* Head-to-Head Comparison Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3 text-xs">
            <span className="font-bold text-slate-300 uppercase tracking-wider">Head-to-Head Comparison:</span>
            <div className="flex items-center space-x-2">
              <select
                value={state1Code}
                onChange={(e) => setState1Code(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-medium focus:outline-none focus:border-emerald-500"
              >
                {MOCK_STATE_METRICS.map((s) => (
                  <option key={s.stateCode} value={s.stateCode}>
                    {s.state} ({s.systemName})
                  </option>
                ))}
              </select>

              <span className="text-slate-500 font-bold">vs</span>

              <select
                value={state2Code}
                onChange={(e) => setState2Code(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-medium focus:outline-none focus:border-emerald-500"
              >
                {MOCK_STATE_METRICS.map((s) => (
                  <option key={s.stateCode} value={s.stateCode}>
                    {s.state} ({s.systemName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="text-xs text-slate-400">
            Source: Department of Land Resources (DoLR) & NCAER Land Governance Framework
          </div>
        </div>

        {/* Head-to-Head Comparative Card */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-800">
          {/* State 1 Card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-extrabold text-white">{state1.state}</h4>
                <div className="text-xs text-emerald-400 font-mono">{state1.systemName}</div>
              </div>
              <button
                onClick={() => onInspectInGIS(state1.stateCode)}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-600 hover:text-white border border-slate-700 text-slate-300 text-xs transition-colors"
              >
                Inspect in GIS
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs pt-1">
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Avg Mutation</span>
                <span className="font-extrabold text-emerald-400 text-sm">{state1.averageMutationDays} Days</span>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Cadastral Vector</span>
                <span className="font-extrabold text-white text-sm">{state1.cadastralDigitizedPct}%</span>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Tenure Score</span>
                <span className="font-extrabold text-teal-400 text-sm">{state1.tenureSecurityIndex}/100</span>
              </div>
            </div>

            <div className="text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
              <span className="text-emerald-400 font-semibold block text-[11px] mb-0.5">Key Innovation:</span>
              {state1.keyReformHighlight}
            </div>
          </div>

          {/* State 2 Card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-teal-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-extrabold text-white">{state2.state}</h4>
                <div className="text-xs text-teal-400 font-mono">{state2.systemName}</div>
              </div>
              <button
                onClick={() => onInspectInGIS(state2.stateCode)}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-teal-600 hover:text-white border border-slate-700 text-slate-300 text-xs transition-colors"
              >
                Inspect in GIS
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs pt-1">
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Avg Mutation</span>
                <span className="font-extrabold text-teal-400 text-sm">{state2.averageMutationDays} Days</span>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Cadastral Vector</span>
                <span className="font-extrabold text-white text-sm">{state2.cadastralDigitizedPct}%</span>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Tenure Score</span>
                <span className="font-extrabold text-cyan-400 text-sm">{state2.tenureSecurityIndex}/100</span>
              </div>
            </div>

            <div className="text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
              <span className="text-teal-400 font-semibold block text-[11px] mb-0.5">Key Innovation:</span>
              {state2.keyReformHighlight}
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive State Leaderboard Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Landmark className="w-4 h-4 text-emerald-400" />
          <span>Full State Land Governance Assessment Matrix</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-3">State & Portal</th>
                <th className="py-3 px-3">Total Villages</th>
                <th className="py-3 px-3">RoR Computerized</th>
                <th className="py-3 px-3">Cadastral Vectorized</th>
                <th className="py-3 px-3">SRO Auto-Sync</th>
                <th className="py-3 px-3">SVAMITVA Drone Cards</th>
                <th className="py-3 px-3">Avg Mutation</th>
                <th className="py-3 px-3">Disputes / 10k</th>
                <th className="py-3 px-3">Tenure Index</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {MOCK_STATE_METRICS.map((st) => (
                <tr key={st.stateCode} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3">
                    <div className="font-bold text-white text-xs">{st.state}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{st.systemName}</div>
                  </td>
                  <td className="py-3 px-3 font-mono">{st.totalVillages.toLocaleString()}</td>
                  <td className="py-3 px-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-medium">
                      {st.computerizedVillagesPct}%
                    </span>
                  </td>
                  <td className="py-3 px-3">{st.cadastralDigitizedPct}%</td>
                  <td className="py-3 px-3 text-teal-300">{st.sroIntegrationPct}%</td>
                  <td className="py-3 px-3 font-mono">{(st.svamitvaDroneParcelsMapped / 100000).toFixed(1)} Lakh</td>
                  <td className="py-3 px-3">
                    <span className={`font-semibold ${st.averageMutationDays <= 7 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {st.averageMutationDays} Days
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono">{st.disputesPer10kParcels}</td>
                  <td className="py-3 px-3">
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-white">{st.tenureSecurityIndex}</span>
                      <div className="w-12 bg-slate-800 rounded-full h-1.5 hidden sm:block">
                        <div
                          className="bg-emerald-400 h-1.5 rounded-full"
                          style={{ width: `${st.tenureSecurityIndex}%` }}
                        />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
