import React, { useState } from 'react';
import {
  Database,
  Search,
  Filter,
  Download,
  FileCode2,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Table,
  Layers,
  Sparkles,
  Building,
  Terminal,
  X
} from 'lucide-react';
import { MOCK_DATASETS } from '../data/mockLandData';
import { LandDataset, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface DataCatalogProps {
  currentLang: LanguageCode;
  onNavigateToApi: () => void;
}

export const DataCatalog: React.FC<DataCatalogProps> = ({ currentLang, onNavigateToApi }) => {
  const t = TRANSLATIONS[currentLang];

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedState, setSelectedState] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [previewDataset, setPreviewDataset] = useState<LandDataset | null>(null);

  const categories = [
    'All',
    'Cadastral & Records',
    'Tenure & Mutations',
    'Agricultural & Non-Agri',
    'Environmental & Conservation',
    'Governance Benchmarks',
    'Tribal Rights & Commons',
  ];

  const states = [
    'All',
    'National',
    'Karnataka',
    'Maharashtra',
    'Telangana',
    'Uttar Pradesh',
    'Multi-State (Odisha, MP, Chhattisgarh, Jharkhand)',
  ];

  const filteredDatasets = MOCK_DATASETS.filter((d) => {
    const matchesCat = selectedCategory === 'All' || d.category === selectedCategory;
    const matchesState = selectedState === 'All' || d.state.includes(selectedState);
    const matchesSearch =
      !searchQuery.trim() ||
      d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCat && matchesState && matchesSearch;
  });

  const handleDownloadDataset = (dataset: LandDataset) => {
    const samplePayload = {
      datasetId: dataset.id,
      title: dataset.title,
      source: dataset.source,
      license: dataset.license,
      exportedAt: new Date().toISOString(),
      sampleRecordAttributes: {
        khasraNumber: "Sy. No. 842/1A",
        ulpin: "KA-DWD-26019-0842-01",
        state: dataset.state,
        recordOfRightsStatus: "Computerized & Digitally Signed",
        spatialVectorPrecision: "±5cm CORS",
        recordsSummary: dataset.recordsCount,
      }
    };

    const blob = new Blob([JSON.stringify(samplePayload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${dataset.id}_sample.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-semibold mb-1">
              <Database className="w-3.5 h-3.5" />
              <span>National Open Land Repository • 100+ Datasets</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Centralized Land Governance Database & Spatial Catalog
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              High-resolution datasets spanning cadastral parcel boundaries, DILRMP modernization metrics, SVAMITVA drone ortho-imagery, Soil Health cards, and Forest Rights Act tribal pattas.
            </p>
          </div>

          <button
            onClick={onNavigateToApi}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 text-xs font-semibold transition-colors"
          >
            <Terminal className="w-4 h-4" />
            <span>Open API Playground</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search datasets by keyword, tag (e.g., ULPIN, SVAMITVA, FRA), or agency..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* State Filter */}
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400 font-medium">State:</span>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
            >
              {states.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-800/80">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  isSelected
                    ? 'bg-emerald-600 text-white font-semibold shadow'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Dataset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDatasets.map((dataset) => (
          <div
            key={dataset.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 shadow-sm space-y-3 transition-all flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {dataset.category}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">{dataset.id}</span>
              </div>

              <h3 className="text-sm font-bold text-white leading-snug hover:text-emerald-300 cursor-pointer"
                  onClick={() => setPreviewDataset(dataset)}>
                {dataset.title}
              </h3>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {dataset.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 pt-1">
                {dataset.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800/80 space-y-3">
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                <div>
                  <span className="text-slate-500 block">Coverage:</span>
                  <span className="text-slate-200 font-medium">{dataset.coverage}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Records Count:</span>
                  <span className="text-emerald-400 font-bold font-mono">{dataset.recordsCount}</span>
                </div>
              </div>

              {/* Format badges & Action buttons */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center space-x-1.5">
                  {dataset.format.map((fmt) => (
                    <span
                      key={fmt}
                      className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-teal-300 border border-slate-700 font-semibold"
                    >
                      {fmt}
                    </span>
                  ))}
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPreviewDataset(dataset)}
                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                  >
                    Inspect
                  </button>
                  <button
                    onClick={() => handleDownloadDataset(dataset)}
                    className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Dataset Preview Modal */}
      {previewDataset && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  Dataset Inspection & Schema
                </span>
                <h3 className="text-base font-extrabold text-white mt-1">
                  {previewDataset.title}
                </h3>
              </div>
              <button
                onClick={() => setPreviewDataset(null)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300 leading-relaxed">
                {previewDataset.description}
              </p>

              <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <span className="text-slate-500 text-[10px] block">Custodian Agency:</span>
                  <span className="text-white font-medium">{previewDataset.source}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Access License:</span>
                  <span className="text-emerald-400 font-medium">{previewDataset.license}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Package Size:</span>
                  <span className="text-white font-medium">{previewDataset.size}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Last Registry Sync:</span>
                  <span className="text-white font-medium">{previewDataset.updatedAt}</span>
                </div>
              </div>

              {/* Sample JSON payload schema */}
              <div>
                <span className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Sample GeoJSON Feature Schema:
                </span>
                <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-teal-300 overflow-x-auto max-h-48">
{`{
  "type": "Feature",
  "geometry": { "type": "Polygon", "coordinates": [[[75.148, 15.395], [75.151, 15.399], ...]] },
  "properties": {
    "ulpin": "KA-DWD-26019-0842-01",
    "khasraNumber": "Sy. No. 842/1A",
    "rorStatus": "Certified Computerized",
    "areaHectares": 2.45,
    "soilHealthScore": 84,
    "corsToleranceCm": 4.8
  }
}`}
                </pre>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setPreviewDataset(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Close
              </button>
              <button
                onClick={() => {
                  handleDownloadDataset(previewDataset);
                  setPreviewDataset(null);
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Download Sample Export</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
