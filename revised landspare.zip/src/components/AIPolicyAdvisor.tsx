import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Download,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  Building2,
  TrendingUp,
  ShieldCheck,
  Scale,
  RefreshCw,
  Copy,
  Check
} from 'lucide-react';
import { LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface AIPolicyAdvisorProps {
  currentLang: LanguageCode;
}

export const AIPolicyAdvisor: React.FC<AIPolicyAdvisorProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];

  const [state, setState] = useState<string>('National (Multi-State)');
  const [focusArea, setFocusArea] = useState<string>('Conclusive Titling & Bhu-Aadhaar Integration');
  const [timeframe, setTimeframe] = useState<string>('Medium-term (2-3 years)');
  const [objective, setObjective] = useState<string>(
    'Eliminate manual mutation notice friction, reduce civil title suits by 60%, and unlock institutional farm credit.'
  );
  const [constraints, setConstraints] = useState<string>(
    'High civil court pendency, fragmented ancestral partitions without survey sub-division, and inter-departmental silos.'
  );

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [policyBrief, setPolicyBrief] = useState<any>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGeneratePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/policy-brief', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state,
          focusArea,
          timeframe,
          objective,
          constraints,
        }),
      });

      const result = await response.json();
      if (result.success && result.data) {
        setPolicyBrief(result.data);
      }
    } catch (err) {
      console.error('Failed to generate policy brief:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!policyBrief) return;
    navigator.clipboard.writeText(JSON.stringify(policyBrief, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!policyBrief) return;
    const blob = new Blob([JSON.stringify(policyBrief, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Landspare_PolicyBrief_${state.replace(/\s+/g, '_')}_2026.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Evidence-Based Policy Engine • Powered by Gemini 3.8</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              AI-Assisted Land Policy & Legal Innovation Advisor
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Synthesize actionable policy briefs, statutory amendments (Registration Act, Land Revenue Code), and operational roadmaps grounded in empirical DILRMP data and LGAF indicators.
            </p>
          </div>

          <div className="text-right hidden sm:block">
            <span className="text-[11px] text-slate-500 block">Grounding Knowledge</span>
            <span className="text-xs font-mono text-emerald-400 font-medium">DoLR • SVAMITVA • Torrens Model • DILRMP</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Policy Form + Output Brief */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md h-fit space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>Policy Parameters</span>
          </h3>

          <form onSubmit={handleGeneratePolicy} className="space-y-4 text-xs">
            {/* Target State */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Target State / Jurisdiction
              </label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="National (Multi-State)">National (Multi-State Pan-India)</option>
                <option value="Karnataka">Karnataka (Bhoomi / Mojini)</option>
                <option value="Maharashtra">Maharashtra (Mahabhumi / 7/12)</option>
                <option value="Telangana">Telangana (Dharani)</option>
                <option value="Uttar Pradesh">Uttar Pradesh (Bhulekh)</option>
                <option value="Gujarat">Gujarat (AnyRoR)</option>
                <option value="Tamil Nadu">Tamil Nadu (Tamil Nilam)</option>
                <option value="Odisha">Odisha (Bhulekh / Jaga Mission)</option>
                <option value="Madhya Pradesh">Madhya Pradesh (Saara)</option>
              </select>
            </div>

            {/* Focus Domain */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Reform Theme / Focus Domain
              </label>
              <select
                value={focusArea}
                onChange={(e) => setFocusArea(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="Conclusive Titling & Bhu-Aadhaar Integration">Conclusive Titling & Bhu-Aadhaar (ULPIN)</option>
                <option value="Accelerated SVAMITVA Inhabited (Abadi) Village Land Monetization">SVAMITVA Drone Survey & Property Cards</option>
                <option value="Forest Rights Act (FRA 2006) Tribal Tenure Demarcation">Tribal Land Security & FRA Forest Pattas</option>
                <option value="Peri-Urban Farmland Protection & Slum Regularization">Peri-Urban Sprawl & Slum Titling (Jaga Model)</option>
                <option value="Sub-Registrar & Revenue Auto-Mutation Handshake">Auto-Mutation (Registry-Tehsildar Single Window)</option>
                <option value="Commons & Wetland Encroachment Mitigation">Commons (Gauchar) & Wetland Geo-Fencing</option>
              </select>
            </div>

            {/* Timeframe */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Policy Horizon
              </label>
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="Short-term (12-18 months)">Short-term (12-18 months Fast-Track)</option>
                <option value="Medium-term (2-3 years)">Medium-term (2-3 years Statewide Rollout)</option>
                <option value="Long-term (5 years)">Long-term (5-year Comprehensive Institutional Reform)</option>
              </select>
            </div>

            {/* Objective */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Primary Objective
              </label>
              <textarea
                rows={3}
                value={objective}
                onChange={(e) => setObjective(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500 text-xs"
              />
            </div>

            {/* Constraints */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Ground Reality Constraints & Bottlenecks
              </label>
              <textarea
                rows={2}
                value={constraints}
                onChange={(e) => setConstraints(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500 text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold shadow-md shadow-emerald-950/60 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Policy Brief...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Evidence-Based Brief</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Output View (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {!policyBrief && !isLoading && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Generate Your First Policy Innovation Brief</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Select your jurisdiction and reform area on the left to consult our Gemini-powered policy formulation engine.
              </p>
              <button
                onClick={handleGeneratePolicy}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium"
              >
                Run Default Pan-India Analysis
              </button>
            </div>
          )}

          {isLoading && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center space-y-4 animate-pulse">
              <div className="w-12 h-12 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Consulting Gemini 3.8 Flash Policy Engine</h3>
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                Cross-referencing DILRMP cadastral vectorization indices, state land revenue code precedents, and Torrens conclusive titling legal architectures...
              </p>
            </div>
          )}

          {policyBrief && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6 animate-in fade-in">
              {/* Document Header & Action Buttons */}
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="space-y-1 max-w-2xl">
                  <div className="flex items-center space-x-2 text-xs">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                      Official Draft Policy Gazette
                    </span>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-400 font-mono text-[11px]">DoLR-NLGP-2026-PB</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                    {policyBrief.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed italic">
                    "{policyBrief.executiveSummary}"
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopy}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors"
                    title="Copy JSON"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export Brief</span>
                  </button>
                </div>
              </div>

              {/* Target Key Metrics Grid */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Targeted Quantitative Deliverables & KPIs
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {policyBrief.keyMetricsTargeted?.map((m: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                      <div className="text-xs font-bold text-white">{m.metric}</div>
                      <div className="flex items-baseline space-x-2">
                        <span className="text-xs text-slate-500 line-through">{m.currentEstimate}</span>
                        <span className="text-sm font-extrabold text-emerald-400">{m.projectedTarget}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">{m.rationale}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Policy Pillars & Statutory Amendments */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Core Strategic Pillars & Statutory Amendments
                </h4>
                <div className="space-y-3">
                  {policyBrief.policyPillars?.map((p: any, idx: number) => (
                    <div key={idx} className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                          {idx + 1}
                        </span>
                        <h5 className="font-bold text-white text-xs sm:text-sm">{p.pillarName}</h5>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed pl-7">
                        {p.strategicIntervention}
                      </p>

                      <div className="pl-7 grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-[11px]">
                        <div className="p-2 rounded bg-slate-900 border border-slate-800/80">
                          <span className="font-semibold text-amber-300 block mb-0.5">Statutory / Legal Amendment:</span>
                          <span className="text-slate-400">{p.legalRegulatoryChanges}</span>
                        </div>
                        <div className="p-2 rounded bg-slate-900 border border-slate-800/80">
                          <span className="font-semibold text-teal-300 block mb-0.5">Technological Enabler:</span>
                          <span className="text-slate-400">{p.technologicalEnabler}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Phased Implementation Roadmap */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Phased Execution Roadmap
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {policyBrief.implementationRoadmap?.map((phase: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-2">
                      <div className="font-bold text-teal-300 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{phase.phase}</span>
                      </div>
                      <ul className="list-disc pl-4 space-y-1 text-slate-300 text-[11px]">
                        {phase.actionItems?.map((a: string, aIdx: number) => (
                          <li key={aIdx}>{a}</li>
                        ))}
                      </ul>
                      <div className="pt-2 border-t border-slate-800/80 text-[10px] text-emerald-400 font-medium">
                        Deliverable: {phase.deliverables}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Socio-Economic Impact Highlights */}
              {policyBrief.socioEconomicImpact && (
                <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-950 to-teal-950/40 border border-emerald-500/30 space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    Socio-Economic & Environmental Safeguards
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="font-semibold text-white block">Farmer & Smallholder Protection:</span>
                      <p className="text-slate-400 text-[11px] mt-0.5">{policyBrief.socioEconomicImpact.farmerProtection}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-white block">Economic Growth Multiplier:</span>
                      <p className="text-slate-400 text-[11px] mt-0.5">{policyBrief.socioEconomicImpact.economicGrowth}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-white block">Environmental Buffer Safeguards:</span>
                      <p className="text-slate-400 text-[11px] mt-0.5">{policyBrief.socioEconomicImpact.environmentalSafeguards}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
