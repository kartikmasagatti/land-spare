import React, { useState } from 'react';
import {
  BookOpen,
  Download,
  Share2,
  FileText,
  User,
  Building,
  CheckCircle2,
  ExternalLink,
  Quote,
  PlusCircle,
  Copy,
  Check,
  X
} from 'lucide-react';
import { MOCK_RESEARCH_PAPERS } from '../data/mockLandData';
import { ResearchPaper, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface ResearchPortalProps {
  currentLang: LanguageCode;
  onNavigateToDataset: (datasetId: string) => void;
}

export const ResearchPortal: React.FC<ResearchPortalProps> = ({
  currentLang,
  onNavigateToDataset,
}) => {
  const t = TRANSLATIONS[currentLang];

  const [papers, setPapers] = useState<ResearchPaper[]>(MOCK_RESEARCH_PAPERS);
  const [selectedPaperForCitation, setSelectedPaperForCitation] = useState<ResearchPaper | null>(null);
  const [citationFormat, setCitationFormat] = useState<'APA' | 'BibTeX'>('APA');
  const [copiedCitation, setCopiedCitation] = useState<boolean>(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState<boolean>(false);

  // New Paper Submission Form State
  const [newTitle, setNewTitle] = useState('');
  const [newAuthors, setNewAuthors] = useState('');
  const [newInstitution, setNewInstitution] = useState('');
  const [newAbstract, setNewAbstract] = useState('');
  const [newCategory, setNewCategory] = useState('Land Economics & Titling');

  const handleCopyCitation = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCitation(true);
    setTimeout(() => setCopiedCitation(false), 2000);
  };

  const handleSubmitPaper = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const createdPaper: ResearchPaper = {
      id: `RP-2026-0${papers.length + 1}`,
      title: newTitle,
      authors: newAuthors.split(',').map((a) => a.trim()),
      institution: newInstitution || 'Independent Research Think Tank',
      publishedDate: 'Just now (Under Review)',
      abstract: newAbstract,
      category: newCategory,
      downloadsCount: 1,
      citationsCount: 0,
      doi: `10.1080/landpol.2026.0${papers.length + 10}`,
      linkedDatasets: ['DS-IND-DILRMP-01'],
      tags: ['Empirical Governance', 'Policy Draft', 'Land Reforms'],
    };

    setPapers([createdPaper, ...papers]);
    setIsSubmitModalOpen(false);
    setNewTitle('');
    setNewAuthors('');
    setNewInstitution('');
    setNewAbstract('');
  };

  const generateCitation = (paper: ResearchPaper, format: 'APA' | 'BibTeX') => {
    if (format === 'APA') {
      return `${paper.authors.join(', ')} (${paper.publishedDate.split(' ')[1] || '2026'}). ${paper.title}. National Digital Platform for Land Governance (Landspare), DOI: ${paper.doi}`;
    }
    return `@article{landspare_${paper.id.toLowerCase().replace(/-/g, '_')},
  author = {${paper.authors.join(' and ')}},
  title = {${paper.title}},
  journal = {Landspare Working Papers Series},
  year = {2026},
  doi = {${paper.doi}},
  url = {https://landspare.gov.in/research/${paper.id}}
}`;
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20 text-xs font-semibold mb-1">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Academic & Policy Research Collaboration Portal</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Land Governance Working Papers & Empirical Evidence
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Collaborative research repository linking econometric field studies with official cadastral datasets from NCAER, NITI Aayog, IIT Bombay, and the World Bank LGAF network.
            </p>
          </div>

          <button
            onClick={() => setIsSubmitModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs shadow-md transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Submit Working Proposal</span>
          </button>
        </div>
      </div>

      {/* Working Papers List */}
      <div className="space-y-4">
        {papers.map((paper) => (
          <div
            key={paper.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-5 shadow-sm space-y-3 transition-colors"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {paper.category}
              </span>
              <div className="flex items-center space-x-3 text-xs text-slate-400">
                <span>{paper.downloadsCount.toLocaleString()} Reads</span>
                <span>•</span>
                <span className="font-semibold text-white">{paper.citationsCount} Citations</span>
                <span>•</span>
                <span className="font-mono text-[11px] text-slate-500">DOI: {paper.doi}</span>
              </div>
            </div>

            <div>
              <h3 className="text-base font-extrabold text-white leading-snug">
                {paper.title}
              </h3>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
                <span className="text-slate-200 font-medium">{paper.authors.join(', ')}</span>
                <span>•</span>
                <span className="text-teal-400">{paper.institution}</span>
                <span>•</span>
                <span>{paper.publishedDate}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
              {paper.abstract}
            </p>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/60">
              {/* Linked Datasets pills */}
              <div className="flex items-center space-x-2 text-xs">
                <span className="text-slate-500 text-[11px]">Linked Datasets:</span>
                <div className="flex flex-wrap gap-1">
                  {paper.linkedDatasets.map((dsId) => (
                    <button
                      key={dsId}
                      onClick={() => onNavigateToDataset(dsId)}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 hover:bg-emerald-600 hover:text-white text-emerald-300 border border-slate-700 transition-colors"
                    >
                      {dsId}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setSelectedPaperForCitation(paper)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Quote className="w-3.5 h-3.5 text-teal-400" />
                  <span>Cite</span>
                </button>
                <a
                  href={`#download-${paper.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    alert(`Initiating download of working paper preprint: "${paper.title}" (PDF)`);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PDF</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Citation Modal */}
      {selectedPaperForCitation && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs font-bold text-teal-400 uppercase tracking-wider">
                  Academic Citation Generator
                </span>
                <h4 className="text-sm font-bold text-white mt-1 line-clamp-1">
                  {selectedPaperForCitation.title}
                </h4>
              </div>
              <button
                onClick={() => setSelectedPaperForCitation(null)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex space-x-2">
              <button
                onClick={() => setCitationFormat('APA')}
                className={`px-3 py-1 rounded text-xs font-semibold ${
                  citationFormat === 'APA' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                APA 7th
              </button>
              <button
                onClick={() => setCitationFormat('BibTeX')}
                className={`px-3 py-1 rounded text-xs font-semibold ${
                  citationFormat === 'BibTeX' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                BibTeX
              </button>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 select-all whitespace-pre-wrap leading-relaxed">
              {generateCitation(selectedPaperForCitation, citationFormat)}
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => handleCopyCitation(generateCitation(selectedPaperForCitation, citationFormat))}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                {copiedCitation ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCitation ? 'Copied to Clipboard' : 'Copy Citation'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Submit Paper Proposal Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white">
                  Submit Research Working Paper / Policy Proposal
                </h3>
                <p className="text-xs text-slate-400">
                  Publish findings to the DoLR & NITI Aayog research repository.
                </p>
              </div>
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPaper} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Paper Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Empirical Evaluation of Instant Mutation in Rural Telangana"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Authors (comma-separated)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Dr. Ravi V., Prof. S. Rao"
                    value={newAuthors}
                    onChange={(e) => setNewAuthors(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Affiliated Institution</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., IIM Bangalore / NLSIU"
                    value={newInstitution}
                    onChange={(e) => setNewInstitution(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Abstract & Policy Findings</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Summarize the core econometric findings, methodology, and suggested legislative amendments..."
                  value={newAbstract}
                  onChange={(e) => setNewAbstract(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Submit for Peer Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
