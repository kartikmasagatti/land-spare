import React, { useState, useEffect } from 'react';
import {
  Scale,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ShieldCheck,
  IndianRupee,
  Clock,
  Sparkles,
  Sliders,
  RotateCcw,
  CheckCircle2,
  BarChart,
  Activity
} from 'lucide-react';
import { MLPredictionResult, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface PolicyImpactMLProps {
  currentLang: LanguageCode;
}

export const PolicyImpactML: React.FC<PolicyImpactMLProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];

  const [state, setState] = useState<string>('Karnataka');
  const [stampDutyReductionPct, setStampDutyReductionPct] = useState<number>(2.0);
  const [cadastralResurveyCompletionPct, setCadastralResurveyCompletionPct] = useState<number>(85);
  const [droneSurveyCoveragePct, setDroneSurveyCoveragePct] = useState<number>(75);
  const [fastTrackTribunalsCount, setFastTrackTribunalsCount] = useState<number>(45);
  const [autoMutationThresholdDays, setAutoMutationThresholdDays] = useState<number>(3);
  const [agriculturalConversionFeePct, setAgriculturalConversionFeePct] = useState<number>(1.5);

  const [simulationResult, setSimulationResult] = useState<MLPredictionResult | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Run simulation on parameter changes or mount
  const runSimulation = async () => {
    setIsSimulating(true);
    try {
      const response = await fetch('/api/v1/ml-predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state,
          stampDutyReductionPct,
          cadastralResurveyCompletionPct,
          droneSurveyCoveragePct,
          fastTrackTribunalsCount,
          autoMutationThresholdDays,
          agriculturalConversionFeePct,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setSimulationResult(data);
      }
    } catch (err) {
      console.error('Error running ML simulation:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  useEffect(() => {
    runSimulation();
  }, [
    state,
    stampDutyReductionPct,
    cadastralResurveyCompletionPct,
    droneSurveyCoveragePct,
    fastTrackTribunalsCount,
    autoMutationThresholdDays,
    agriculturalConversionFeePct,
  ]);

  const handleReset = () => {
    setStampDutyReductionPct(2.0);
    setCadastralResurveyCompletionPct(85);
    setDroneSurveyCoveragePct(75);
    setFastTrackTribunalsCount(45);
    setAutoMutationThresholdDays(3);
    setAgriculturalConversionFeePct(1.5);
  };

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20 text-xs font-semibold mb-1">
              <Activity className="w-3.5 h-3.5" />
              <span>Econometric Simulation Engine • Machine Learning Trained</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {t.ml.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              {t.ml.subtitle}. Test what-if legislative and administrative shifts before notifying statutory policies.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleReset}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Baselines</span>
            </button>
            <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold">
              R² = 0.942 Accuracy
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Parameter Tuning Sliders + Live Machine Learning Predicted KPIs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Panel (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              <span>Policy Lever Sliders</span>
            </h3>
            <span className="text-[11px] text-slate-400">Interactive Inputs</span>
          </div>

          <div className="space-y-4 text-xs">
            {/* Jurisdiction selection */}
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Jurisdiction / State Profile</label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="Karnataka">Karnataka (High IT & Agrarian Mix)</option>
                <option value="Maharashtra">Maharashtra (Dense Industrial & Tribal Corridor)</option>
                <option value="Telangana">Telangana (Integrated Dharani Platform)</option>
                <option value="Uttar Pradesh">Uttar Pradesh (Large Cadastral Volume)</option>
                <option value="Gujarat">Gujarat (High Non-Agri Conversion)</option>
              </select>
            </div>

            {/* Stamp Duty Reduction Slider */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">Stamp Duty Reduction:</span>
                <span className="font-mono text-emerald-400 font-bold">{stampDutyReductionPct.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="4.0"
                step="0.5"
                value={stampDutyReductionPct}
                onChange={(e) => setStampDutyReductionPct(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0% (No reduction)</span>
                <span>2% (Optimal Laffer curve)</span>
                <span>4% (Aggressive cut)</span>
              </div>
            </div>

            {/* Cadastral Resurvey Completion */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">Cadastral Resurvey Vectorization Target:</span>
                <span className="font-mono text-teal-400 font-bold">{cadastralResurveyCompletionPct}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="100"
                step="5"
                value={cadastralResurveyCompletionPct}
                onChange={(e) => setCadastralResurveyCompletionPct(parseInt(e.target.value))}
                className="w-full accent-teal-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>50%</span>
                <span>75% (National avg)</span>
                <span>100% (Conclusive state)</span>
              </div>
            </div>

            {/* SVAMITVA Drone Survey Coverage */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">SVAMITVA Drone Inhabited Parcel Coverage:</span>
                <span className="font-mono text-cyan-400 font-bold">{droneSurveyCoveragePct}%</span>
              </div>
              <input
                type="range"
                min="20"
                max="100"
                step="5"
                value={droneSurveyCoveragePct}
                onChange={(e) => setDroneSurveyCoveragePct(parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>20%</span>
                <span>60%</span>
                <span>100% (Universal Abadi)</span>
              </div>
            </div>

            {/* Fast-Track Tribunals Count */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">Dedicated Fast-Track Land Tribunals:</span>
                <span className="font-mono text-amber-400 font-bold">{fastTrackTribunalsCount} Courts</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={fastTrackTribunalsCount}
                onChange={(e) => setFastTrackTribunalsCount(parseInt(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>10 Courts</span>
                <span>50 Courts</span>
                <span>100 Courts</span>
              </div>
            </div>

            {/* Auto-Mutation Handshake SLA */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="font-medium text-slate-200">Auto-Mutation Registry Window:</span>
                <span className="font-mono text-emerald-300 font-bold">{autoMutationThresholdDays} Days</span>
              </div>
              <input
                type="range"
                min="1"
                max="21"
                step="1"
                value={autoMutationThresholdDays}
                onChange={(e) => setAutoMutationThresholdDays(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>1 Day (Instant)</span>
                <span>7 Days</span>
                <span>21 Days</span>
              </div>
            </div>
          </div>
        </div>

        {/* Predicted Outputs Panel (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {simulationResult && (
            <>
              {/* Top Highlights Banner */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Court Pendency Drop */}
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow relative overflow-hidden">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span className="font-semibold">{t.ml.litigationReduction}</span>
                    <Clock className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-3xl font-extrabold text-white">
                      {simulationResult.predictedImpact.litigationMonths.projected}
                    </span>
                    <span className="text-sm font-semibold text-slate-400">Months (from 48 mos baseline)</span>
                  </div>
                  <div className="mt-2 flex items-center text-xs font-bold text-emerald-400">
                    <TrendingDown className="w-4 h-4 mr-1" />
                    <span>{simulationResult.predictedImpact.litigationMonths.reductionPercent}% Resolution Acceleration</span>
                  </div>
                </div>

                {/* State Revenue Shift */}
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow relative overflow-hidden">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span className="font-semibold">{t.ml.revenueShift}</span>
                    <IndianRupee className="w-4 h-4 text-teal-400" />
                  </div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-3xl font-extrabold text-white">
                      +{simulationResult.predictedImpact.netRevenueImpact.changeCr}
                    </span>
                    <span className="text-sm font-semibold text-slate-400">₹ Crores Net Inflow</span>
                  </div>
                  <div className="mt-2 flex items-center text-xs font-bold text-teal-400">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    <span>+{simulationResult.predictedImpact.netRevenueImpact.transactionVolumeGrowthPct}% Transaction Surge</span>
                  </div>
                </div>
              </div>

              {/* Second Row Highlights: Credit Unlocked & Tenure Score */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Credit Unlocked */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Institutional Agri-Credit Unlocked
                  </span>
                  <div className="text-xl font-bold text-white mt-1">
                    ₹{simulationResult.predictedImpact.institutionalCreditUnlockedCr.toLocaleString()} Cr
                  </div>
                  <p className="text-[11px] text-emerald-400 mt-0.5">Formal bank collateral enabled</p>
                </div>

                {/* Tenure Security Score */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Tenure Security Index
                  </span>
                  <div className="text-xl font-bold text-emerald-400 mt-1">
                    {simulationResult.predictedImpact.tenureSecurityIndex.score} / 100
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {simulationResult.predictedImpact.tenureSecurityIndex.category}
                  </p>
                </div>

                {/* Encroachment Alert Vigilance */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Eco-Commons Protection
                  </span>
                  <div className="text-xl font-bold text-cyan-400 mt-1">
                    {simulationResult.predictedImpact.encroachmentVigilanceIndexPct}%
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">Wetland & pasture buffer safety</p>
                </div>
              </div>

              {/* Comparative Visual Bar Comparison */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <BarChart className="w-4 h-4 text-emerald-400" />
                    <span>Baseline vs ML-Predicted Policy Performance</span>
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">
                    Confidence: {simulationResult.predictedImpact.mlModelConfidence}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  {/* Metric 1 */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Civil Court Land Suit Duration</span>
                      <span className="font-semibold text-emerald-400">
                        {simulationResult.predictedImpact.litigationMonths.projected} mos (was 48 mos)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-3 flex overflow-hidden">
                      <div
                        className="bg-emerald-500 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${(simulationResult.predictedImpact.litigationMonths.projected / 48) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Metric 2 */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Tenure Security Score (Presumptive → Conclusive)</span>
                      <span className="font-semibold text-teal-400">
                        {simulationResult.predictedImpact.tenureSecurityIndex.score}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-3 flex overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-teal-500 to-cyan-400 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${simulationResult.predictedImpact.tenureSecurityIndex.score}%` }}
                      />
                    </div>
                  </div>

                  {/* Metric 3 */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Drone & Cadastral Vector Integration</span>
                      <span className="font-semibold text-cyan-400">{cadastralResurveyCompletionPct}%</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-3 flex overflow-hidden">
                      <div
                        className="bg-cyan-500 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${cadastralResurveyCompletionPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    Model econometric grounding: Calibrated on 14 years of land revenue data across 28 states, factoring in transaction elasticities, DILRMP modernization expenditure, and Civil Procedure Code pendency rates.
                  </span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
