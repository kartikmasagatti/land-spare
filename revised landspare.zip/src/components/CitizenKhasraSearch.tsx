import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  AlertTriangle,
  FileCheck2,
  Printer,
  Download,
  ShieldCheck,
  Building,
  User,
  MapPin,
  HelpCircle,
  Clock,
  Sparkles,
  Send
} from 'lucide-react';
import { MOCK_CADASTRAL_PARCELS } from '../data/mockLandData';
import { CadastralParcel, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface CitizenKhasraSearchProps {
  currentLang: LanguageCode;
  onInspectInGIS: (parcel: CadastralParcel) => void;
}

export const CitizenKhasraSearch: React.FC<CitizenKhasraSearchProps> = ({
  currentLang,
  onInspectInGIS,
}) => {
  const t = TRANSLATIONS[currentLang];

  const [state, setState] = useState('Karnataka');
  const [district, setDistrict] = useState('Dharwad');
  const [searchType, setSearchType] = useState<'khasra' | 'ulpin' | 'owner'>('khasra');
  const [searchTerm, setSearchTerm] = useState('842/1A');
  const [searchedParcel, setSearchedParcel] = useState<CadastralParcel | null>(MOCK_CADASTRAL_PARCELS[0]);
  const [isGrievanceOpen, setIsGrievanceOpen] = useState(false);
  const [grievanceType, setGrievanceType] = useState('Boundary Demarcation Request (Mojini / DGPS)');
  const [grievanceSubmitted, setGrievanceSubmitted] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;

    const term = searchTerm.toLowerCase();
    const match = MOCK_CADASTRAL_PARCELS.find(
      (p) =>
        p.khasraNumber.toLowerCase().includes(term) ||
        p.ulpin.toLowerCase().includes(term) ||
        p.primaryOwner.toLowerCase().includes(term)
    );

    setSearchedParcel(match || null);
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-semibold mb-1">
              <User className="w-3.5 h-3.5" />
              <span>Public Citizen & Landowner Services • Jan-Seva Portal</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Verified Public Land Record & Khasra Inspection (7/12 / RTC / Patta)
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Inspect authentic Record of Rights (RoRs), verify 14-digit Bhu-Aadhaar (ULPIN), check mutation trails, and generate tamper-proof digital certificates without visiting Tehsildar offices.
            </p>
          </div>

          <button
            onClick={() => setIsGrievanceOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
            <span>File Demarcation / Grievance</span>
          </button>
        </div>
      </div>

      {/* Search Input Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <span className="text-slate-300 font-semibold">Search by:</span>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setSearchType('khasra')}
              className={`px-3 py-1 rounded text-xs font-medium ${
                searchType === 'khasra' ? 'bg-emerald-600 text-white' : 'text-slate-400'
              }`}
            >
              Survey / Khasra No
            </button>
            <button
              onClick={() => setSearchType('ulpin')}
              className={`px-3 py-1 rounded text-xs font-medium ${
                searchType === 'ulpin' ? 'bg-emerald-600 text-white' : 'text-slate-400'
              }`}
            >
              Bhu-Aadhaar (ULPIN)
            </button>
            <button
              onClick={() => setSearchType('owner')}
              className={`px-3 py-1 rounded text-xs font-medium ${
                searchType === 'owner' ? 'bg-emerald-600 text-white' : 'text-slate-400'
              }`}
            >
              Khatedar Name
            </button>
          </div>
        </div>

        <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">State</label>
            <select
              value={state}
              onChange={(e) => setState(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white"
            >
              <option value="Karnataka">Karnataka (Bhoomi)</option>
              <option value="Maharashtra">Maharashtra (Mahabhumi)</option>
              <option value="Telangana">Telangana (Dharani)</option>
              <option value="Uttar Pradesh">Uttar Pradesh (Bhulekh)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">District</label>
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white"
            >
              <option value="Dharwad">Dharwad</option>
              <option value="Belagavi">Belagavi</option>
              <option value="Bengaluru Rural">Bengaluru Rural</option>
              <option value="Mysuru">Mysuru</option>
            </select>
          </div>

          <div className="sm:col-span-2 flex items-end gap-2">
            <div className="flex-1">
              <label className="block text-[11px] text-slate-400 mb-1">
                {searchType === 'khasra'
                  ? 'Enter Survey Number (e.g., 842/1A, 842/2B, 843/GAU)'
                  : searchType === 'ulpin'
                  ? 'Enter 14-Digit Bhu-Aadhaar Code'
                  : 'Enter Landowner Full Name'}
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="e.g. 842/1A"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow flex items-center gap-1.5 h-9"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Search</span>
            </button>
          </div>
        </form>
      </div>

      {/* Search Result & Official Digital Certificate */}
      {searchedParcel ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          {/* Certificate Header with Government Watermark Aesthetic */}
          <div className="border-b border-slate-800 pb-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-xl bg-slate-950 border border-emerald-500/40 flex items-center justify-center text-xl font-bold text-emerald-400">
                🇮🇳
              </div>
              <div>
                <div className="text-xs font-bold text-emerald-400 tracking-wider uppercase">
                  Government of {searchedParcel.state} • Revenue Department
                </div>
                <h3 className="text-lg font-extrabold text-white">
                  Digital Record of Rights (Pahani / Form No. 16)
                </h3>
                <span className="text-[11px] text-slate-400">
                  Certified Electronic Copy under IT Act 2000 Section 65B
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => onInspectInGIS(searchedParcel)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>View on GIS Map</span>
              </button>
              <button
                onClick={handlePrintCertificate}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Certificate</span>
              </button>
            </div>
          </div>

          {/* Certificate Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Survey / Khasra Number</span>
              <div className="text-base font-bold text-white">{searchedParcel.khasraNumber}</div>
              <span className="text-[10px] text-slate-400">Hissa / Division: Sub-plot A</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Bhu-Aadhaar (14-Digit ULPIN)</span>
              <div className="font-mono text-sm font-bold text-teal-300">{searchedParcel.ulpin}</div>
              <span className="text-[10px] text-emerald-400 font-medium">✓ Georeferenced Centroid Valid</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Title Encumbrance / Lien</span>
              <div className="text-sm font-bold">
                {searchedParcel.encumbranceFlag ? (
                  <span className="text-amber-400">Active Bank Lien Registered</span>
                ) : (
                  <span className="text-emerald-400">Zero Encumbrance (Clean)</span>
                )}
              </div>
              <span className="text-[10px] text-slate-400">
                {searchedParcel.encumbranceDetails || 'No registered mortgages or court stays'}
              </span>
            </div>
          </div>

          {/* Detailed RoR Attributes Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/70">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900 text-slate-400 text-[11px] uppercase border-b border-slate-800">
                <tr>
                  <th className="p-3">Primary Khatedar / Owner</th>
                  <th className="p-3">Extent (Area)</th>
                  <th className="p-3">Classification</th>
                  <th className="p-3">Soil Index</th>
                  <th className="p-3">SVAMITVA Drone</th>
                  <th className="p-3">Litigation Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr>
                  <td className="p-3 font-bold text-white">
                    {searchedParcel.primaryOwner}
                    <div className="text-[10px] text-slate-500 font-normal">
                      Joint Holders: {searchedParcel.jointHoldersCount} Registered Heirs
                    </div>
                  </td>
                  <td className="p-3 font-semibold text-white">{searchedParcel.areaHectares} Hectares</td>
                  <td className="p-3 text-emerald-300">{searchedParcel.landUse}</td>
                  <td className="p-3 font-mono">{searchedParcel.soilHealthIndex || 78}/100</td>
                  <td className="p-3">
                    {searchedParcel.droneSurveyCompleted ? (
                      <span className="text-cyan-400 font-medium">Mapped (±5cm)</span>
                    ) : (
                      <span className="text-slate-500">Pending</span>
                    )}
                  </td>
                  <td className="p-3">
                    {searchedParcel.disputeFlag ? (
                      <span className="text-rose-400 font-bold">Court Dispute Active</span>
                    ) : (
                      <span className="text-emerald-400 font-semibold">Clear Title</span>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* QR Verification & Legal Note */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded bg-white p-1 flex items-center justify-center font-mono font-bold text-slate-900 text-[10px] text-center leading-tight">
                QR CODE
              </div>
              <div>
                <span className="text-slate-300 font-semibold block">Cryptographic Hash Verification</span>
                <span className="font-mono text-[10px] text-slate-500 select-all">
                  SHA-256: e8b9412cf30a10985b88f34177b902e88a7c81
                </span>
              </div>
            </div>

            <div className="text-right text-[11px] text-slate-400">
              <span>Settlement Commissioner & Director of Land Records</span>
              <span className="block text-emerald-400 font-medium">Certified Digitally Signed</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center space-y-2">
          <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
          <h4 className="text-base font-bold text-white">No Matching Land Record Found</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Please verify the Survey / Khasra number or 14-digit Bhu-Aadhaar. Ensure you have selected the correct District and State.
          </p>
        </div>
      )}

      {/* Citizen Grievance / Demarcation Modal */}
      {isGrievanceOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white">
                  File Online Citizen Demarcation & Grievance
                </h3>
                <p className="text-xs text-slate-400">
                  Instant electronic filing with Tehsil Revenue Court & Mojini GIS Hub.
                </p>
              </div>
              <button
                onClick={() => setIsGrievanceOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {grievanceSubmitted ? (
              <div className="p-6 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <h4 className="text-base font-bold text-white">Grievance Registered Successfully</h4>
                <p className="text-xs text-slate-300">
                  Acknowledgement Number: <strong className="text-emerald-400 font-mono">GRV-2026-KA-84201</strong>
                </p>
                <p className="text-[11px] text-slate-400">
                  A SMS notification has been dispatched to the registered mobile number. A DGPS surveyor visit is scheduled within 7 business days under the Sakala / Citizen Guarantee Act.
                </p>
                <button
                  onClick={() => {
                    setGrievanceSubmitted(false);
                    setIsGrievanceOpen(false);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                >
                  Done
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setGrievanceSubmitted(true);
                }}
                className="space-y-3 text-xs"
              >
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Grievance / Request Category</label>
                  <select
                    value={grievanceType}
                    onChange={(e) => setGrievanceType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Boundary Demarcation Request (Mojini / DGPS)">
                      Joint Boundary Demarcation Request (Mojini / DGPS)
                    </option>
                    <option value="Ancestral Partition / Sub-division (Podi) Application">
                      Ancestral Partition / Sub-division (Podi / Hissa)
                    </option>
                    <option value="Correction of Name / Khatauni Spelling Mistake">
                      Correction of Name / Spelling in RoR
                    </option>
                    <option value="Mutation Latency Grievance (Notice Expiry)">
                      Delayed Mutation Clearance (Exceeded SLA)
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Survey No / Khasra</label>
                  <input
                    type="text"
                    required
                    defaultValue="Sy. No. 842/1A"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Applicant Contact Phone</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 98765 43210"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Statement of Facts</label>
                  <textarea
                    rows={3}
                    placeholder="Describe boundary contention or specific partition requirement..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsGrievanceOpen(false)}
                    className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Grievance</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
