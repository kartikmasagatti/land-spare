import React, { useState } from 'react';
import {
  Terminal,
  Send,
  Copy,
  Check,
  Code2,
  Key,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  Server
} from 'lucide-react';
import { LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface OpenAPIPlaygroundProps {
  currentLang: LanguageCode;
}

export const OpenAPIPlayground: React.FC<OpenAPIPlaygroundProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];

  const endpoints = [
    {
      id: 'datasets',
      method: 'GET',
      path: '/api/v1/datasets',
      title: 'Query Land Datasets Catalog',
      desc: 'Retrieve metadata, spatial vector links, and DILRMP status across states.',
      params: '?category=Cadastral&state=Karnataka',
      defaultBody: '',
    },
    {
      id: 'ml-predict',
      method: 'POST',
      path: '/api/v1/ml-predict',
      title: 'Run Econometric Policy Impact ML Model',
      desc: 'Simulate the impact of stamp duty, cadastral resurvey, and drone mapping on court pendency and state revenue.',
      params: '',
      defaultBody: JSON.stringify(
        {
          state: 'Karnataka',
          stampDutyReductionPct: 2.0,
          cadastralResurveyCompletionPct: 85,
          droneSurveyCoveragePct: 75,
          fastTrackTribunalsCount: 45,
          autoMutationThresholdDays: 3,
        },
        null,
        2
      ),
    },
    {
      id: 'analyze-parcel',
      method: 'POST',
      path: '/api/ai/analyze-parcel',
      title: 'Analyze Parcel Dispute & Title Risk',
      desc: 'Evaluate Khasra title encumbrance and legal feasibility of conclusive titling.',
      params: '',
      defaultBody: JSON.stringify(
        {
          khasraNumber: 'Sy. No. 842/2B',
          state: 'Karnataka',
          district: 'Dharwad',
          areaHectares: 1.82,
          tenureType: 'Ancestral Joint',
          disputeHistory: 'Pending partition suit in Civil Court Hubballi',
          encumbranceFlag: true,
        },
        null,
        2
      ),
    },
  ];

  const [selectedEndpoint, setSelectedEndpoint] = useState(endpoints[0]);
  const [requestBody, setRequestBody] = useState(endpoints[0].defaultBody);
  const [requestParams, setRequestParams] = useState(endpoints[0].params);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseBody, setResponseBody] = useState<any>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeLangSnippet, setActiveLangSnippet] = useState<'curl' | 'python' | 'js'>('curl');
  const [copiedSnippet, setCopiedSnippet] = useState<boolean>(false);

  const handleSelectEndpoint = (ep: typeof endpoints[0]) => {
    setSelectedEndpoint(ep);
    setRequestBody(ep.defaultBody);
    setRequestParams(ep.params);
    setResponseBody(null);
    setResponseStatus(null);
    setLatencyMs(null);
  };

  const handleExecuteRequest = async () => {
    setIsLoading(true);
    const startTime = performance.now();

    try {
      const url = `${selectedEndpoint.path}${requestParams}`;
      const options: RequestInit = {
        method: selectedEndpoint.method,
        headers: { 'Content-Type': 'application/json' },
      };

      if (selectedEndpoint.method === 'POST') {
        options.body = requestBody;
      }

      const res = await fetch(url, options);
      const endTime = performance.now();

      setResponseStatus(res.status);
      setLatencyMs(Math.round(endTime - startTime));

      const data = await res.json();
      setResponseBody(data);
    } catch (err: any) {
      setResponseStatus(500);
      setResponseBody({ error: err.message || 'Request failed' });
    } finally {
      setIsLoading(false);
    }
  };

  const generateSnippet = () => {
    const fullUrl = `https://landspare.gov.in${selectedEndpoint.path}${requestParams}`;
    if (activeLangSnippet === 'curl') {
      if (selectedEndpoint.method === 'GET') {
        return `curl -X GET "${fullUrl}" \\
  -H "Authorization: Bearer landspare_research_token" \\
  -H "Accept: application/json"`;
      }
      return `curl -X POST "${fullUrl}" \\
  -H "Authorization: Bearer landspare_research_token" \\
  -H "Content-Type: application/json" \\
  -d '${requestBody.replace(/\n/g, ' ')}'`;
    } else if (activeLangSnippet === 'python') {
      return `import requests

url = "${fullUrl}"
headers = {
    "Authorization": "Bearer landspare_research_token",
    "Content-Type": "application/json"
}
${
  selectedEndpoint.method === 'POST'
    ? `payload = ${requestBody}
response = requests.post(url, json=payload, headers=headers)`
    : `response = requests.get(url, headers=headers)`
}
data = response.json()
print(data)`;
    } else {
      return `const response = await fetch("${fullUrl}", {
  method: "${selectedEndpoint.method}",
  headers: {
    "Authorization": "Bearer landspare_research_token",
    "Content-Type": "application/json"
  }${selectedEndpoint.method === 'POST' ? `,\n  body: JSON.stringify(${requestBody})` : ''}
});
const data = await response.json();
console.log(data);`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-semibold mb-1">
              <Terminal className="w-3.5 h-3.5" />
              <span>Developer & Research Institute Gateway</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Open API Playground & Integration Sandbox
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              High-throughput RESTful programmatic interface for universities, think tanks, and policy researchers to stream cadastral vector boundaries, econometric simulation models, and title validation engines.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center space-x-2.5">
            <Key className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="font-mono text-slate-300 font-semibold">TOKEN: landspare_research_sandbox</div>
              <span className="text-[10px] text-emerald-400">Institutional Quota: 10,000 Req / Day</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Console Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Endpoints Sidebar (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-2">
            Available Endpoints
          </div>

          <div className="space-y-2">
            {endpoints.map((ep) => {
              const isSelected = selectedEndpoint.id === ep.id;
              return (
                <button
                  key={ep.id}
                  onClick={() => handleSelectEndpoint(ep)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition-all ${
                    isSelected
                      ? 'bg-slate-950 border-emerald-500/50 shadow-md text-white'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${
                        ep.method === 'GET'
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {ep.method}
                    </span>
                    <span className="font-mono text-slate-200 truncate">{ep.path}</span>
                  </div>
                  <div className="font-semibold text-white mt-1.5">{ep.title}</div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{ep.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Request / Response Workbench (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Request Header Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-4">
            <div className="flex items-center space-x-2">
              <span
                className={`text-xs font-bold px-2 py-1 rounded font-mono ${
                  selectedEndpoint.method === 'GET'
                    ? 'bg-blue-500/20 text-blue-400'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {selectedEndpoint.method}
              </span>

              <div className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-xs text-white flex items-center">
                <span className="text-slate-500">https://landspare.gov.in</span>
                <span className="text-teal-300 font-semibold">{selectedEndpoint.path}</span>
                <input
                  type="text"
                  value={requestParams}
                  onChange={(e) => setRequestParams(e.target.value)}
                  placeholder="?params"
                  className="bg-transparent border-none text-emerald-400 focus:outline-none flex-1 ml-1"
                />
              </div>

              <button
                onClick={handleExecuteRequest}
                disabled={isLoading}
                className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow transition-all disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isLoading ? 'Sending...' : 'Send'}</span>
              </button>
            </div>

            {/* Request Body (for POST) */}
            {selectedEndpoint.method === 'POST' && (
              <div className="space-y-1 text-xs">
                <span className="font-semibold text-slate-400">Request JSON Body:</span>
                <textarea
                  rows={6}
                  value={requestBody}
                  onChange={(e) => setRequestBody(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 font-mono text-xs text-teal-300 focus:outline-none focus:border-emerald-500"
                />
              </div>
            )}
          </div>

          {/* Response Viewer */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
              <div className="flex items-center space-x-3">
                <span className="font-bold text-white uppercase tracking-wider">Live Response</span>
                {responseStatus && (
                  <span
                    className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                      responseStatus === 200 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    STATUS {responseStatus}
                  </span>
                )}
                {latencyMs !== null && (
                  <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {latencyMs} ms
                  </span>
                )}
              </div>

              {responseBody && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify(responseBody, null, 2));
                  }}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy JSON</span>
                </button>
              )}
            </div>

            <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto max-h-72">
              {responseBody
                ? JSON.stringify(responseBody, null, 2)
                : '// Click "Send" above to execute API call and inspect the JSON payload'}
            </pre>
          </div>

          {/* Code Snippets Generator */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Code2 className="w-4 h-4 text-emerald-400" />
                <span>Client Code Integration Snippet</span>
              </span>

              <div className="flex items-center space-x-1">
                {(['curl', 'python', 'js'] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setActiveLangSnippet(lang)}
                    className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-colors ${
                      activeLangSnippet === lang
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    {lang.toUpperCase()}
                  </button>
                ))}
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generateSnippet());
                    setCopiedSnippet(true);
                    setTimeout(() => setCopiedSnippet(false), 2000);
                  }}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 ml-2"
                  title="Copy snippet"
                >
                  {copiedSnippet ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-teal-300 overflow-x-auto whitespace-pre-wrap">
              {generateSnippet()}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
