import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  Layers,
  MapPin,
  Search,
  ShieldAlert,
  ShieldCheck,
  Plane,
  Sprout,
  Compass,
  Sparkles,
  Eye,
  CheckCircle2,
  AlertOctagon,
  FileText,
  Building,
  RefreshCw
} from 'lucide-react';
import { MOCK_CADASTRAL_PARCELS, MOCK_STATE_METRICS } from '../data/mockLandData';
import { CadastralParcel, LanguageCode } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface GISMapViewerProps {
  currentLang: LanguageCode;
  selectedStateCode?: string;
  onSelectParcel?: (parcel: CadastralParcel) => void;
}

export const GISMapViewer: React.FC<GISMapViewerProps> = ({
  currentLang,
  selectedStateCode = 'KA',
  onSelectParcel,
}) => {
  const t = TRANSLATIONS[currentLang];
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layersGroupRef = useRef<L.LayerGroup | null>(null);

  const [selectedParcel, setSelectedParcel] = useState<CadastralParcel>(MOCK_CADASTRAL_PARCELS[0]);
  const [activeBaseLayer, setActiveBaseLayer] = useState<'osm' | 'satellite'>('osm');
  const [showParcels, setShowParcels] = useState<boolean>(true);
  const [showDroneGrid, setShowDroneGrid] = useState<boolean>(true);
  const [showEcoBuffers, setShowEcoBuffers] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // AI Parcel Dispute Analysis state
  const [isAnalyzingRisk, setIsAnalyzingRisk] = useState<boolean>(false);
  const [aiRiskReport, setAiRiskReport] = useState<any>(null);

  // Initialize and update Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Default to Karnataka Dharwad area where we have granular mock parcels
      const map = L.map(mapContainerRef.current, {
        center: [15.396, 75.1515],
        zoom: 14,
        zoomControl: false,
      });

      L.control.zoom({ position: 'topright' }).addTo(map);

      // Add Tile Layer
      const baseTileUrl = activeBaseLayer === 'osm'
        ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
        : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';

      const tileLayer = L.tileLayer(baseTileUrl, {
        attribution: '&copy; OpenStreetMap contributors & Survey of India / DoLR',
        maxZoom: 19,
      }).addTo(map);

      // Group for vector overlays
      const layersGroup = L.layerGroup().addTo(map);

      mapInstanceRef.current = map;
      layersGroupRef.current = layersGroup;
      (map as any)._currentTileLayer = tileLayer;
    }

    return () => {
      // Clean up map instance if unmounted
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Handle Base Layer Switch (OSM vs Satellite)
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    if ((map as any)._currentTileLayer) {
      map.removeLayer((map as any)._currentTileLayer);
    }

    const baseTileUrl = activeBaseLayer === 'osm'
      ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';

    const tileLayer = L.tileLayer(baseTileUrl, {
      attribution: '&copy; OpenStreetMap contributors & ESRI Satellite / DoLR',
      maxZoom: 19,
    }).addTo(map);

    (map as any)._currentTileLayer = tileLayer;
  }, [activeBaseLayer]);

  // Handle Vector Overlay Drawing
  useEffect(() => {
    if (!mapInstanceRef.current || !layersGroupRef.current) return;
    const lg = layersGroupRef.current;
    lg.clearLayers();

    // 1. Cadastral Parcels
    if (showParcels) {
      MOCK_CADASTRAL_PARCELS.forEach((parcel) => {
        let fillColor = '#10b981'; // Green for Agri
        let strokeColor = '#059669';

        if (parcel.landUse === 'Gauchar (Pasture)') {
          fillColor = '#3b82f6';
          strokeColor = '#2563eb';
        } else if (parcel.landUse === 'Industrial') {
          fillColor = '#8b5cf6';
          strokeColor = '#7c3aed';
        } else if (parcel.landUse === 'Water Body') {
          fillColor = '#06b6d4';
          strokeColor = '#0891b2';
        } else if (parcel.landUse === 'Forest/Buffer') {
          fillColor = '#047857';
          strokeColor = '#065f46';
        }

        // Highlight disputed parcel with dashed red outline
        const isDisputed = parcel.disputeFlag;
        const isSelected = selectedParcel?.id === parcel.id;

        const polygon = L.polygon(parcel.coordinates, {
          color: isSelected ? '#f59e0b' : isDisputed ? '#ef4444' : strokeColor,
          weight: isSelected ? 3.5 : isDisputed ? 2.5 : 2,
          dashArray: isDisputed ? '4, 4' : undefined,
          fillColor: fillColor,
          fillOpacity: isSelected ? 0.65 : 0.35,
        });

        // Hover Tooltip
        polygon.bindTooltip(
          `<div class="text-xs font-sans">
            <strong>${parcel.khasraNumber}</strong><br/>
            Owner: ${parcel.primaryOwner}<br/>
            Area: ${parcel.areaHectares} Ha (${parcel.landUse})<br/>
            ${isDisputed ? '<span style="color:#ef4444;font-weight:bold;">⚠️ Active Litigation</span>' : '<span style="color:#10b981;">✓ Clear Presumptive Title</span>'}
          </div>`,
          { sticky: true, opacity: 0.95 }
        );

        polygon.on('click', () => {
          setSelectedParcel(parcel);
          setAiRiskReport(null);
          if (onSelectParcel) onSelectParcel(parcel);
        });

        lg.addLayer(polygon);

        // Add Marker at center with Khasra number
        const textIcon = L.divIcon({
          className: 'cadastral-label',
          html: `<div style="background: rgba(15, 23, 42, 0.85); color: #f8fafc; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px; border: 1px solid rgba(255,255,255,0.2); white-space: nowrap; transform: translate(-50%, -50%);">
            ${parcel.khasraNumber.replace('Sy. No. ', '')}
          </div>`,
          iconSize: [0, 0],
        });
        const marker = L.marker(parcel.center, { icon: textIcon });
        lg.addLayer(marker);
      });
    }

    // 2. Drone Survey (SVAMITVA) Flight Grid Overlay
    if (showDroneGrid) {
      const droneFlightPath: [number, number][] = [
        [15.392, 75.145],
        [15.405, 75.145],
        [15.405, 75.150],
        [15.392, 75.150],
        [15.392, 75.155],
        [15.405, 75.155],
        [15.405, 75.160],
        [15.392, 75.160],
      ];

      const polyline = L.polyline(droneFlightPath, {
        color: '#06b6d4',
        weight: 1.5,
        dashArray: '6, 6',
        opacity: 0.8,
      });
      polyline.bindTooltip("SVAMITVA Drone Survey Grid • Ground Sampling 4.8cm GSD");
      lg.addLayer(polyline);
    }

    // 3. Eco-buffer / Wetland alert polygon
    if (showEcoBuffers) {
      const wetlandBuffer = L.circle([15.389, 75.1505], {
        radius: 350,
        color: '#f59e0b',
        weight: 1.5,
        dashArray: '3, 6',
        fillColor: '#f59e0b',
        fillOpacity: 0.1,
      });
      wetlandBuffer.bindTooltip("Kusugal Lake Statutory Eco-Fragile Buffer (50m Prohibitory No-Development Zone)");
      lg.addLayer(wetlandBuffer);
    }
  }, [showParcels, showDroneGrid, showEcoBuffers, selectedParcel]);

  // Handle Search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const matched = MOCK_CADASTRAL_PARCELS.find(
      (p) =>
        p.khasraNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.ulpin.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.primaryOwner.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (matched && mapInstanceRef.current) {
      setSelectedParcel(matched);
      setAiRiskReport(null);
      mapInstanceRef.current.setView(matched.center, 16, { animate: true });
    }
  };

  // Trigger AI Dispute Risk Analysis
  const handleAnalyzeParcelRisk = async () => {
    if (!selectedParcel) return;
    setIsAnalyzingRisk(true);
    setAiRiskReport(null);

    try {
      const res = await fetch('/api/ai/analyze-parcel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          khasraNumber: selectedParcel.khasraNumber,
          state: selectedParcel.state,
          district: selectedParcel.district,
          areaHectares: selectedParcel.areaHectares,
          tenureType: selectedParcel.ownershipType,
          disputeHistory: selectedParcel.disputeDetails,
          encumbranceFlag: selectedParcel.encumbranceFlag,
        }),
      });
      const json = await res.json();
      if (json.success && json.data) {
        setAiRiskReport(json.data);
      }
    } catch (err) {
      console.error("Failed to analyze parcel:", err);
    } finally {
      setIsAnalyzingRisk(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Controls Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-md flex flex-wrap items-center justify-between gap-3">
        {/* Search Input */}
        <form onSubmit={handleSearch} className="flex items-center space-x-2 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search Survey No (e.g. 842/1A), Bhu-Aadhaar, or Owner Name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
          >
            Locate
          </button>
        </form>

        {/* Layer Toggles & Map Type Switch */}
        <div className="flex items-center space-x-2 text-xs">
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveBaseLayer('osm')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                activeBaseLayer === 'osm' ? 'bg-slate-800 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Street Cadastre
            </button>
            <button
              onClick={() => setActiveBaseLayer('satellite')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                activeBaseLayer === 'satellite' ? 'bg-slate-800 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Satellite (ISRO/ESRI)
            </button>
          </div>

          <div className="hidden sm:flex items-center space-x-2 pl-2 border-l border-slate-800">
            <label className="flex items-center space-x-1.5 text-slate-300 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showParcels}
                onChange={(e) => setShowParcels(e.target.checked)}
                className="rounded bg-slate-950 border-slate-700 text-emerald-500 focus:ring-0"
              />
              <span>Parcels</span>
            </label>

            <label className="flex items-center space-x-1.5 text-slate-300 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showDroneGrid}
                onChange={(e) => setShowDroneGrid(e.target.checked)}
                className="rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0"
              />
              <span>SVAMITVA Drone</span>
            </label>

            <label className="flex items-center space-x-1.5 text-slate-300 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={showEcoBuffers}
                onChange={(e) => setShowEcoBuffers(e.target.checked)}
                className="rounded bg-slate-950 border-slate-700 text-amber-500 focus:ring-0"
              />
              <span>Eco-Buffers</span>
            </label>
          </div>
        </div>
      </div>

      {/* Main Map + Inspector Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Leaflet GIS Interactive Canvas */}
        <div className="lg:col-span-2 relative h-[560px] rounded-xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
          <div ref={mapContainerRef} className="w-full h-full z-10" />

          {/* Map Overlay Badge & Legend */}
          <div className="absolute top-3 left-3 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg p-2.5 text-[11px] shadow-lg text-slate-200 max-w-xs pointer-events-none">
            <div className="font-bold text-white flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-emerald-400" />
              <span>Dharwad District Cadastral Vector Hub</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              CORS Base Station: KA-DWD-01 (±4.8cm RMSE) • Projection: EPSG:3857
            </p>

            <div className="mt-2 pt-2 border-t border-slate-800 grid grid-cols-2 gap-1.5 text-[10px]">
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded bg-emerald-500/80 border border-emerald-400" />
                <span>Agricultural</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded bg-blue-500/80 border border-blue-400" />
                <span>Gauchar Commons</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded bg-purple-500/80 border border-purple-400" />
                <span>Industrial Zone</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded border border-rose-500 border-dashed bg-rose-500/30" />
                <span className="text-rose-300">Active Litigation</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Parcel Inspector & Record of Rights (RoR) Drawer */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-4 max-h-[560px] overflow-y-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                Cadastral Record of Rights (RoR)
              </span>
              <h3 className="text-base font-extrabold text-white flex items-center gap-1.5">
                <span>{selectedParcel.khasraNumber}</span>
                {selectedParcel.disputeFlag ? (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    Disputed
                  </span>
                ) : (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Verified
                  </span>
                )}
              </h3>
            </div>
            <button
              onClick={() => {
                if (mapInstanceRef.current) {
                  mapInstanceRef.current.setView(selectedParcel.center, 16, { animate: true });
                }
              }}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
              title="Center on map"
            >
              <Eye className="w-4 h-4 text-emerald-400" />
            </button>
          </div>

          {/* Bhu-Aadhaar 14-digit ULPIN */}
          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">
              Bhu-Aadhaar (14-Digit ULPIN)
            </div>
            <div className="font-mono text-xs font-bold text-teal-300 tracking-wide select-all">
              {selectedParcel.ulpin}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              Geo-referenced Centroid: {selectedParcel.center[0].toFixed(5)}°N, {selectedParcel.center[1].toFixed(5)}°E
            </div>
          </div>

          {/* Land Attributes Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded bg-slate-950/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Village & Taluk</span>
              <span className="font-medium text-white">{selectedParcel.village}, {selectedParcel.taluk}</span>
            </div>
            <div className="p-2 rounded bg-slate-950/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Parcel Area</span>
              <span className="font-medium text-white">{selectedParcel.areaHectares} Hectares</span>
            </div>
            <div className="p-2 rounded bg-slate-950/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Land Use Class</span>
              <span className="font-medium text-emerald-300">{selectedParcel.landUse}</span>
            </div>
            <div className="p-2 rounded bg-slate-950/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Tenure System</span>
              <span className="font-medium text-white">{selectedParcel.ownershipType}</span>
            </div>
          </div>

          {/* Primary Owner & Joint Holders */}
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Khatedar / Primary Owner</div>
            <div className="font-semibold text-white text-xs">{selectedParcel.primaryOwner}</div>
            <div className="text-[11px] text-slate-400">
              Joint Right Holders: <span className="text-white font-medium">{selectedParcel.jointHoldersCount}</span>
            </div>
          </div>

          {/* Soil Health & Drone Status */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded bg-slate-950/60 border border-slate-800">
              <div className="flex items-center space-x-1 text-slate-400 text-[10px]">
                <Sprout className="w-3 h-3 text-emerald-400" />
                <span>Soil Health Index</span>
              </div>
              <div className="text-sm font-bold text-emerald-400 mt-1">
                {selectedParcel.soilHealthIndex || 78} / 100
              </div>
              <span className="text-[10px] text-slate-500">NPK Optimum</span>
            </div>

            <div className="p-2 rounded bg-slate-950/60 border border-slate-800">
              <div className="flex items-center space-x-1 text-slate-400 text-[10px]">
                <Plane className="w-3 h-3 text-cyan-400" />
                <span>SVAMITVA Drone</span>
              </div>
              <div className="text-sm font-bold text-cyan-400 mt-1">
                {selectedParcel.droneSurveyCompleted ? "Completed" : "Scheduled"}
              </div>
              <span className="text-[10px] text-slate-500">±5cm Survey of India</span>
            </div>
          </div>

          {/* Litigation / Dispute Notice Banner */}
          {selectedParcel.disputeFlag ? (
            <div className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-800 text-rose-200 text-xs space-y-1">
              <div className="font-bold flex items-center gap-1 text-rose-300">
                <AlertOctagon className="w-4 h-4 text-rose-400" />
                <span>Active Title Dispute Flagged</span>
              </div>
              <p className="text-[11px] text-rose-200/90 leading-relaxed">
                {selectedParcel.disputeDetails}
              </p>
            </div>
          ) : (
            <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-800/80 text-emerald-300 text-xs flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Clean presumptive title. Zero recorded boundary or inheritance litigations.</span>
            </div>
          )}

          {/* AI Dispute Risk Engine CTA */}
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={handleAnalyzeParcelRisk}
              disabled={isAnalyzingRisk}
              className="w-full flex items-center justify-center space-x-2 py-2 px-3 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium text-xs shadow-md transition-all disabled:opacity-50"
            >
              {isAnalyzingRisk ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Consulting Gemini Dispute Engine...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>AI Dispute Risk & Resolution Feasibility</span>
                </>
              )}
            </button>

            {/* AI Risk Report View */}
            {aiRiskReport && (
              <div className="mt-3 p-3 rounded-lg bg-slate-950 border border-emerald-500/40 text-xs space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-1 text-[11px]">
                    <Sparkles className="w-3 h-3 text-emerald-400" />
                    AI Legal Analysis
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    aiRiskReport.riskScore > 50 ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                  }`}>
                    Risk: {aiRiskReport.riskScore}/100 ({aiRiskReport.riskCategory})
                  </span>
                </div>

                <div className="space-y-1 text-[11px]">
                  <span className="font-semibold text-slate-300">Recommended Resolution Pathway:</span>
                  <ul className="list-disc pl-4 space-y-0.5 text-slate-400 text-[10px]">
                    {aiRiskReport.recommendedResolution?.map((step: string, idx: number) => (
                      <li key={idx}>{step}</li>
                    ))}
                  </ul>
                </div>

                <div className="text-[10px] text-slate-500 italic pt-1 border-t border-slate-800">
                  Precedent: {aiRiskReport.regulatoryPrecedents}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
