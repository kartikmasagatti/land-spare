import React from 'react';
import {
  Globe,
  Layers,
  Sparkles,
  BarChart3,
  Scale,
  Database,
  BookOpen,
  Terminal,
  Search,
  CheckCircle2,
  Building2,
  Award,
  ChevronDown
} from 'lucide-react';
import { LanguageCode, UserPersona } from '../types/landspare';
import { TRANSLATIONS } from '../i18n/translations';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  activePersona: UserPersona;
  setActivePersona: (p: UserPersona) => void;
  currentLang: LanguageCode;
  setCurrentLang: (l: LanguageCode) => void;
  onOpenQuickSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  activePersona,
  setActivePersona,
  currentLang,
  setCurrentLang,
  onOpenQuickSearch,
}) => {
  const t = TRANSLATIONS[currentLang];

  const personaDetails: Record<UserPersona, { label: string; icon: string; desc: string }> = {
    policymaker: {
      label: t.personas.policymaker,
      icon: '🏛️',
      desc: 'DoLR / Revenue Secretaries',
    },
    researcher: {
      label: t.personas.researcher,
      icon: '🔬',
      desc: 'Think Tanks, IITs, Universities',
    },
    citizen: {
      label: t.personas.citizen,
      icon: '🌾',
      desc: 'Farmers & Urban Landowners',
    },
    environmentalist: {
      label: t.personas.environmentalist,
      icon: '🌿',
      desc: 'Commons & Eco-Zone Analysts',
    },
  };

  const navItems = [
    { id: 'overview', label: t.nav.overview, icon: BarChart3 },
    { id: 'gis', label: t.nav.gisMap, icon: Layers, highlight: true },
    { id: 'ai-advisor', label: t.nav.aiAdvisor, icon: Sparkles, badge: 'Gemini' },
    { id: 'policy-ml', label: t.nav.policyML, icon: Scale, badge: 'ML' },
    { id: 'state-matrix', label: t.nav.stateComparison, icon: Building2 },
    { id: 'datasets', label: t.nav.dataCatalog, icon: Database, count: '100+' },
    { id: 'research', label: t.nav.researchPortal, icon: BookOpen },
    { id: 'api', label: t.nav.openApi, icon: Terminal },
    { id: 'citizen', label: t.nav.citizenSearch, icon: Search },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-xl">
      {/* Top Bar with SIH 2026 Badge, Government Tri-Color Accent & Persona Selector */}
      <div className="h-1 bg-gradient-to-r from-orange-500 via-white to-emerald-500" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Brand & SIH identity */}
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center font-black text-xl shadow-md border border-emerald-400/40 text-white">
                LS
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  Landspare
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold">
                    v2.6 Enterprise
                  </span>
                </h1>
                <div className="hidden md:flex items-center gap-1.5 text-xs bg-slate-800 px-2.5 py-0.5 rounded border border-slate-700 text-slate-300">
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold text-emerald-300">National Land Governance Platform</span>
                </div>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block truncate max-w-xl">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Right Controls: Persona Switcher, Language Selector & Quick Action */}
          <div className="flex items-center space-x-2.5">
            {/* Quick Khasra Search Trigger */}
            <button
              onClick={onOpenQuickSearch}
              className="flex items-center space-x-2 px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded-lg text-xs text-slate-300 transition-all hover:text-white"
            >
              <Search className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Search Khasra / ULPIN</span>
              <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] bg-slate-900 border border-slate-700 rounded text-slate-400">⌘K</kbd>
            </button>

            {/* Persona Switcher Dropdown */}
            <div className="relative group">
              <button className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs text-slate-200">
                <span>{personaDetails[activePersona].icon}</span>
                <span className="font-medium hidden sm:inline">{personaDetails[activePersona].label}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>
              
              <div className="absolute right-0 mt-1 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1.5 hidden group-hover:block z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 border-b border-slate-800 uppercase tracking-wider">
                  Switch Active Persona
                </div>
                {(Object.keys(personaDetails) as UserPersona[]).map((pKey) => {
                  const p = personaDetails[pKey];
                  const isSelected = activePersona === pKey;
                  return (
                    <button
                      key={pKey}
                      onClick={() => setActivePersona(pKey)}
                      className={`w-full text-left px-3 py-2 flex items-start space-x-2.5 hover:bg-slate-800/70 transition-colors ${
                        isSelected ? 'bg-emerald-950/40 text-emerald-300 border-l-2 border-emerald-400' : 'text-slate-300'
                      }`}
                    >
                      <span className="text-base">{p.icon}</span>
                      <div className="flex-1">
                        <div className="text-xs font-medium flex items-center justify-between">
                          <span>{p.label}</span>
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                        </div>
                        <p className="text-[10px] text-slate-400">{p.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Language Selector */}
            <div className="relative group">
              <button className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs text-slate-200">
                <Globe className="w-3.5 h-3.5 text-teal-400" />
                <span className="font-medium">{TRANSLATIONS[currentLang].nativeName}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              <div className="absolute right-0 mt-1 w-44 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 hidden group-hover:block z-50">
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 border-b border-slate-800">
                  Select Language (भाषा)
                </div>
                {(Object.keys(TRANSLATIONS) as LanguageCode[]).map((langKey) => {
                  const l = TRANSLATIONS[langKey];
                  const isSelected = currentLang === langKey;
                  return (
                    <button
                      key={langKey}
                      onClick={() => setCurrentLang(langKey)}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                        isSelected ? 'text-emerald-400 font-semibold bg-emerald-950/30' : 'text-slate-300'
                      }`}
                    >
                      <span>{l.nativeName} ({l.name})</span>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Feature Tabs Navigation */}
      <div className="border-t border-slate-800/80 bg-slate-950/60 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 py-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase tracking-wider ${
                    isActive ? 'bg-white/20 text-white' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  }`}>
                    {item.badge}
                  </span>
                )}
                {item.count && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
