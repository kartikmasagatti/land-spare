export type UserPersona = 'policymaker' | 'researcher' | 'citizen' | 'environmentalist';

export type LanguageCode = 'en' | 'hi' | 'kn' | 'mr' | 'te' | 'ta';

export interface CadastralParcel {
  id: string;
  khasraNumber: string;
  ulpin: string; // 14-digit Unique Land Parcel Identification Number (Bhu-Aadhaar)
  state: string;
  district: string;
  taluk: string;
  village: string;
  areaHectares: number;
  landUse: 'Agricultural' | 'Residential' | 'Commercial' | 'Industrial' | 'Forest/Buffer' | 'Gauchar (Pasture)' | 'Water Body';
  ownershipType: 'Private Freehold' | 'Ancestral Joint' | 'State Government' | 'Gram Sabha Commons' | 'Tribal Patta (FRA)';
  primaryOwner: string;
  jointHoldersCount: number;
  disputeFlag: boolean;
  disputeDetails?: string;
  encumbranceFlag: boolean;
  encumbranceDetails?: string;
  soilHealthIndex?: number; // 0 - 100
  droneSurveyCompleted: boolean;
  coordinates: [number, number][]; // Polygon lat/lngs
  center: [number, number];
}

export interface StateLandMetric {
  state: string;
  stateCode: string;
  systemName: string; // e.g. Bhoomi, Dharani, Mahabhumi
  totalVillages: number;
  computerizedVillagesPct: number;
  cadastralDigitizedPct: number;
  sroIntegrationPct: number; // Sub-Registrar Office integration
  svamitvaDroneParcelsMapped: number;
  averageMutationDays: number;
  disputesPer10kParcels: number;
  tenureSecurityIndex: number; // 0 - 100
  keyReformHighlight: string;
  centerCoordinates: [number, number];
  zoomLevel: number;
}

export interface LandDataset {
  id: string;
  title: string;
  category: 'Cadastral & Records' | 'Tenure & Mutations' | 'Agricultural & Non-Agri' | 'Environmental & Conservation' | 'Governance Benchmarks' | 'Tribal Rights & Commons';
  state: string;
  recordsCount: string;
  updatedAt: string;
  coverage: string;
  format: string[];
  tags: string[];
  description: string;
  size: string;
  license: string;
  source: string;
}

export interface ResearchPaper {
  id: string;
  title: string;
  authors: string[];
  institution: string;
  publishedDate: string;
  abstract: string;
  category: string;
  downloadsCount: number;
  citationsCount: number;
  doi: string;
  linkedDatasets: string[];
  tags: string[];
}

export interface MLPredictionResult {
  simulationParameters: {
    state: string;
    stampDutyReductionPct: number;
    cadastralResurveyCompletionPct: number;
    droneSurveyCoveragePct: number;
    fastTrackTribunalsCount: number;
    autoMutationThresholdDays: number;
    agriculturalConversionFeePct: number;
  };
  predictedImpact: {
    litigationMonths: {
      baseline: number;
      projected: number;
      reductionPercent: number;
    };
    netRevenueImpact: {
      changeCr: number;
      percentageShift: string;
      transactionVolumeGrowthPct: string;
    };
    tenureSecurityIndex: {
      score: number;
      category: string;
    };
    institutionalCreditUnlockedCr: number;
    encroachmentVigilanceIndexPct: number;
    mlModelConfidence: string;
  };
}
