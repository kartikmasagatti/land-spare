import { LanguageCode } from '../types/landspare';

export const TRANSLATIONS: Record<LanguageCode, {
  name: string;
  flag: string;
  nativeName: string;
  tagline: string;
  nav: {
    overview: string;
    gisMap: string;
    aiAdvisor: string;
    policyML: string;
    stateComparison: string;
    dataCatalog: string;
    researchPortal: string;
    openApi: string;
    citizenSearch: string;
  };
  personas: {
    policymaker: string;
    researcher: string;
    citizen: string;
    environmentalist: string;
  };
  stats: {
    villagesDigitized: string;
    bhuAadhaarGenerated: string;
    disputeReduction: string;
    datasetsAvailable: string;
    openApiEndpoints: string;
  };
  gis: {
    title: string;
    subtitle: string;
    parcelDetails: string;
    layers: string;
    inspectParcel: string;
    droneSurvey: string;
    soilHealth: string;
    disputeRisk: string;
  };
  policy: {
    generateBrief: string;
    targetState: string;
    policyArea: string;
    horizon: string;
    objective: string;
    generating: string;
    downloadBrief: string;
  };
  ml: {
    title: string;
    subtitle: string;
    runSimulation: string;
    litigationReduction: string;
    revenueShift: string;
    creditUnlocked: string;
    tenureSecurity: string;
  };
}> = {
  en: {
    name: 'English',
    flag: '🇮🇳',
    nativeName: 'English',
    tagline: 'National Digital Platform for Research, Policy Innovation & Evidence-Based Land Governance',
    nav: {
      overview: 'Executive Overview',
      gisMap: 'GIS Land Cadastre',
      aiAdvisor: 'AI Policy Advisor',
      policyML: 'ML Impact Simulator',
      stateComparison: 'State Policy Matrix',
      dataCatalog: '100+ Land Datasets',
      researchPortal: 'Research Papers',
      openApi: 'Open API Console',
      citizenSearch: 'Citizen Khasra Search',
    },
    personas: {
      policymaker: 'Policymaker / DoLR',
      researcher: 'Academic Researcher',
      citizen: 'Citizen / Landowner',
      environmentalist: 'Eco / Buffer Analyst',
    },
    stats: {
      villagesDigitized: 'Villages Digitized (DILRMP)',
      bhuAadhaarGenerated: 'Bhu-Aadhaar (ULPIN) Issued',
      disputeReduction: 'Avg Dispute Resolution Reduction',
      datasetsAvailable: 'Open Geospatial Datasets',
      openApiEndpoints: 'Institution API Endpoints',
    },
    gis: {
      title: 'Cadastral GIS & Land Use Viewer',
      subtitle: 'High-resolution parcel georeferencing with Bhu-Aadhaar and dispute risk overlays',
      parcelDetails: 'Parcel Record of Rights (RoR)',
      layers: 'Spatial Layers',
      inspectParcel: 'Select a parcel to inspect cadastral title',
      droneSurvey: 'SVAMITVA Drone Georeferencing',
      soilHealth: 'Soil Health Card Index',
      disputeRisk: 'AI Dispute Risk Assessment',
    },
    policy: {
      generateBrief: 'Synthesize Evidence-Based Policy Brief',
      targetState: 'Target Jurisdiction',
      policyArea: 'Reform Sector / Theme',
      horizon: 'Policy Horizon',
      objective: 'Strategic Objective',
      generating: 'Consulting Gemini Policy Engine...',
      downloadBrief: 'Export Policy Gazette (JSON / Brief)',
    },
    ml: {
      title: 'Policy Impact Machine Learning Predictor',
      subtitle: 'Simulate policy interventions on land litigation, state revenue, and smallholder credit',
      runSimulation: 'Recalculate Econometric Model',
      litigationReduction: 'Court Pendency Reduction',
      revenueShift: 'State Revenue Impact',
      creditUnlocked: 'Agri-Credit Unlocked',
      tenureSecurity: 'Tenure Security Index',
    }
  },
  hi: {
    name: 'हिन्दी',
    flag: '🇮🇳',
    nativeName: 'हिन्दी',
    tagline: 'अनुसंधान, नीति नवाचार और साक्ष्य-आधारित भूमि शासन के लिए राष्ट्रीय डिजिटल मंच',
    nav: {
      overview: 'कार्यकारी अवलोकन',
      gisMap: 'जीआईएस भू-अभिलेख',
      aiAdvisor: 'एआई नीति सलाहकार',
      policyML: 'एमएल प्रभाव सिम्युलेटर',
      stateComparison: 'राज्य नीति तुलना',
      dataCatalog: '100+ भूमि डेटासेट',
      researchPortal: 'शोध पत्र एवं सहयोग',
      openApi: 'ओपन एपीआई कंसोल',
      citizenSearch: 'नागरिक खसरा खोज',
    },
    personas: {
      policymaker: 'नीति निर्माता / डीओएलआर',
      researcher: 'अकादमिक शोधकर्ता',
      citizen: 'नागरिक / भूस्वामी',
      environmentalist: 'पर्यावरण एवं संरक्षण विश्लेषक',
    },
    stats: {
      villagesDigitized: 'डिजिटलीकृत गाँव (डीआईएलआरएमपी)',
      bhuAadhaarGenerated: 'भू-आधार (यूएलपीआईएन) जारी',
      disputeReduction: 'विवाद समाधान समय में कमी',
      datasetsAvailable: 'खुले भू-स्थानिक डेटासेट',
      openApiEndpoints: 'संस्थान एपीआई एंडपॉइंट्स',
    },
    gis: {
      title: 'कैडस्ट्रल जीआईएस एवं भूमि उपयोग मानचित्र',
      subtitle: 'भू-आधार और विवाद जोखिम के साथ उच्च-सटीक भूखंड भू-संदर्भ',
      parcelDetails: 'भूखंड अधिकार अभिलेख (खतौनी/आरओआर)',
      layers: 'स्थानिक परतें',
      inspectParcel: 'कैडस्ट्रल स्वामित्व जांचने के लिए भूखंड चुनें',
      droneSurvey: 'स्वामित्व ड्रोन सर्वेक्षण',
      soilHealth: 'मृदा स्वास्थ्य सूचकांक',
      disputeRisk: 'एआई विवाद जोखिम मूल्यांकन',
    },
    policy: {
      generateBrief: 'साक्ष्य-आधारित नीति संक्षिप्त विवरण तैयार करें',
      targetState: 'लक्षित राज्य / क्षेत्र',
      policyArea: 'सुधार क्षेत्र / विषय',
      horizon: 'नीति समयसीमा',
      objective: 'रणनीतिक उद्देश्य',
      generating: 'जेमिनी नीति इंजन से परामर्श जारी...',
      downloadBrief: 'नीति राजपत्र निर्यात करें',
    },
    ml: {
      title: 'नीति प्रभाव मशीन लर्निंग भविष्यवक्ता',
      subtitle: 'भूमि मुकदमों, राज्य राजस्व और कृषि ऋण पर नीतिगत प्रभावों का अनुकरण करें',
      runSimulation: 'अर्थमितीय मॉडल पुनर्गणना',
      litigationReduction: 'न्यायालयी लंबित मामलों में कमी',
      revenueShift: 'राज्य राजस्व प्रभाव',
      creditUnlocked: 'सुलभ संस्थागत ऋण',
      tenureSecurity: 'पट्टा सुरक्षा सूचकांक',
    }
  },
  kn: {
    name: 'ಕನ್ನಡ',
    flag: '🇮🇳',
    nativeName: 'ಕನ್ನಡ',
    tagline: 'ಸಂಶೋಧನೆ, ನೀತಿ ನಾವೀನ್ಯತೆ ಮತ್ತು ಪುರಾವೆ-ಆಧಾರಿತ ಭೂ ಆಡಳಿತಕ್ಕಾಗಿ ರಾಷ್ಟ್ರೀಯ ಡಿಜಿಟಲ್ ವೇದಿಕೆ',
    nav: {
      overview: 'ಕಾರ್ಯನಿರ್ವಾಹಕ ನೋಟ',
      gisMap: 'ಜಿಐಎಸ್ ಭೂ ನಕ್ಷೆ (ಭೂಮಿ)',
      aiAdvisor: 'ಎಐ ನೀತಿ ಸಲಹೆಗಾರ',
      policyML: 'ಎಂಎಲ್ ಪ್ರಭಾವ ಸಿಮ್ಯುಲೇಟರ್',
      stateComparison: 'ರಾಜ್ಯ ನೀತಿ ಹೋಲಿಕೆ',
      dataCatalog: '100+ ಭೂ ದತ್ತಾಂಶಗಳು',
      researchPortal: 'ಸಂಶೋಧನಾ ಪತ್ರಿಕೆಗಳು',
      openApi: 'ಮುಕ್ತ ಎಪಿಐ ಕನ್ಸೋಲ್',
      citizenSearch: 'ನಾಗರಿಕ ಸರ್ವೆ ನಂಬರ್ ಶೋಧ',
    },
    personas: {
      policymaker: 'ನೀತಿ ನಿರೂಪಕರು / ಕಂದಾಯ ಇಲಾಖೆ',
      researcher: 'ಸಂಶೋಧಕರು',
      citizen: 'ರೈತ / ಭೂಮಾಲೀಕ',
      environmentalist: 'ಪರಿಸರ ವಿಶ್ಲೇಷಕ',
    },
    stats: {
      villagesDigitized: 'ಗಣಕೀಕೃತ ಗ್ರಾಮಗಳು (ಭೂಮಿ/DILRMP)',
      bhuAadhaarGenerated: 'ಭೂ-ಆಧಾರ್ (ULPIN) ವಿತರಣೆ',
      disputeReduction: 'ವಿವಾದ ಇತ್ಯರ್ಥ ಅವಧಿ ಇಳಿಕೆ',
      datasetsAvailable: 'ಲಭ್ಯವಿರುವ ಭೂ ದತ್ತಾಂಶಗಳು',
      openApiEndpoints: 'ಸಂಶೋಧನಾ ಎಪಿಐಗಳು',
    },
    gis: {
      title: 'ಕ್ಯಾಡಾಸ್ಟ್ರಲ್ ಜಿಐಎಸ್ ಮತ್ತು ಆರ್ಟಿಸಿ ವಿವರಗಳು',
      subtitle: 'ಭೂ-ಆಧಾರ್ ಮತ್ತು ಗಡಿ ನಿರ್ಣಯದೊಂದಿಗೆ ಹೈ-ರೆಸಲ್ಯೂಶನ್ ಸರ್ವೆ ನಕ್ಷೆಗಳು',
      parcelDetails: 'ಪಹಣಿ / ಆರ್ಟಿಸಿ ದಾಖಲೆ',
      layers: 'ಸ್ಪೇಷಿಯಲ್ ಲೇಯರ್‌ಗಳು',
      inspectParcel: 'ಮಾಹಿತಿ ವೀಕ್ಷಿಸಲು ಸರ್ವೆ ನಂಬರ್ ಆಯ್ಕೆಮಾಡಿ',
      droneSurvey: 'ಸ್ವಾಮಿತ್ವ ಡ್ರೋನ್ ಸರ್ವೆಕ್ಷಣೆ',
      soilHealth: 'ಮಣ್ಣಿನ ಆರೋಗ್ಯ ಸೂಚ್ಯಂಕ',
      disputeRisk: 'ಎಐ ವಿವಾದ ಅಪಾಯ ವಿಶ್ಲೇಷಣೆ',
    },
    policy: {
      generateBrief: 'ಪುರಾವೆ ಆಧಾರಿತ ನೀತಿ ಕರಡು ರಚಿಸಿ',
      targetState: 'ಉದ್ದೇಶಿತ ರಾಜ್ಯ',
      policyArea: 'ಸುಧಾರಣಾ ವಲಯ',
      horizon: 'ಕಾಲಾವಧಿ',
      objective: 'ಗುರಿ ಮತ್ತು ಉದ್ದೇಶ',
      generating: 'ಜೆಮಿನಿ ಎಐ ಸಿದ್ಧಪಡಿಸುತ್ತಿದೆ...',
      downloadBrief: 'ನೀತಿ ಕರಡು ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ',
    },
    ml: {
      title: 'ಎಂಎಲ್ ನೀತಿ ಪ್ರಭಾವ ಮುನ್ಸೂಚನೆ ಎಂಜಿನ್',
      subtitle: 'ಸ್ಟ್ಯಾಂಪ್ ಶುಲ್ಕ ಮತ್ತು ಗಣಕೀಕರಣದ ಆರ್ಥಿಕ ಪ್ರಭಾವ ಸಿಮ್ಯುಲೇಷನ್',
      runSimulation: 'ಮಾದರಿ ಮರು-ಲೆಕ್ಕಾಚಾರ',
      litigationReduction: 'ನ್ಯಾಯಾಲಯದ ಮೊಕದ್ದಮೆ ಇಳಿಕೆ',
      revenueShift: 'ರಾಜ್ಯ ಕಂದಾಯ ಬದಲಾವಣೆ',
      creditUnlocked: 'ರೈತರಿಗೆ ಸಾಲ ಸೌಲಭ್ಯ ವೃದ್ಧಿ',
      tenureSecurity: 'ಭೂ ಒಡೆತನ ಭದ್ರತಾ ಸೂಚ್ಯಂಕ',
    }
  },
  mr: {
    name: 'मराठी',
    flag: '🇮🇳',
    nativeName: 'मराठी',
    tagline: 'संशोधन, धोरण नवोपक्रम आणि पुरावा-आधारित भू-प्रशासनासाठी राष्ट्रीय डिजिटल व्यासपीठ',
    nav: {
      overview: 'कार्यकारी आढावा',
      gisMap: 'जीआयएस जमीन नकाशा (महाभूमी)',
      aiAdvisor: 'एआय धोरण सल्लागार',
      policyML: 'एमएल प्रभाव सिम्युलेटर',
      stateComparison: 'राज्य धोरण तुलना',
      dataCatalog: '100+ जमीन डेटासेट',
      researchPortal: 'संशोधन निबंध',
      openApi: 'मुक्त एपीआय कन्सोल',
      citizenSearch: 'नागरिक ७/१२ फेरफार शोध',
    },
    personas: {
      policymaker: 'धोरणकर्ते / जमाबंदी आयुक्त',
      researcher: 'संशोधक',
      citizen: 'नागरिक / खातेदार शेतकरी',
      environmentalist: 'पर्यावरण विश्लेषक',
    },
    stats: {
      villagesDigitized: 'डिजिटल गावे (ई-महाभूमी)',
      bhuAadhaarGenerated: 'भू-आधार (ULPIN) वितरित',
      disputeReduction: 'वाद निवारण वेळेत घट',
      datasetsAvailable: 'उपलब्ध डेटासेट्स',
      openApiEndpoints: 'एपीआय एंडपॉईंट्स',
    },
    gis: {
      title: 'कॅडस्ट्रल जीआयएस आणि ७/१२ भूखंड दर्शक',
      subtitle: 'भू-आधार आणि ई-हक्क फेरफार जोडणीसह अचूक नकाशा',
      parcelDetails: '७/१२ व ८-अ उतारा तपशील',
      layers: 'नकाशा स्तर',
      inspectParcel: 'तपशील पाहण्यासाठी गट नंबर निवडा',
      droneSurvey: 'स्वामित्व ड्रोन मोजणी',
      soilHealth: 'मृदा आरोग्य निर्देशांक',
      disputeRisk: 'एआय वाद जोखीम मूल्यांकन',
    },
    policy: {
      generateBrief: 'पुरावा-आधारित धोरण मसुदा तयार करा',
      targetState: 'लक्षित राज्य',
      policyArea: 'सुधारणा क्षेत्र',
      horizon: 'कालावधी',
      objective: 'उद्दिष्ट',
      generating: 'जेमिनी एआय विश्लेषण करत आहे...',
      downloadBrief: 'धोरण मसुदा डाउनलोड करा',
    },
    ml: {
      title: 'धोरण प्रभाव मशीन लर्निंग अंदाज प्रणाली',
      subtitle: 'मुद्रांक शुल्क आणि डिजिटल मोजणीचे आर्थिक परिणाम तपासा',
      runSimulation: 'मॉडेल फेरगणना',
      litigationReduction: 'न्यायालयीन प्रकरणांमध्ये घट',
      revenueShift: 'महसूल प्रभाव',
      creditUnlocked: 'शेतकरी पतपुरवठा वाढ',
      tenureSecurity: 'मालकी हक्क सुरक्षा निर्देशांक',
    }
  },
  te: {
    name: 'తెలుగు',
    flag: '🇮🇳',
    nativeName: 'తెలుగు',
    tagline: 'పరిశోధన, విధాన ఆవిష్కరణ మరియు సాక్ష్యాల ఆధారిత భూ పరిపాలన కోసం జాతీయ డిజిటల్ వేదిక',
    nav: {
      overview: 'సమీక్ష',
      gisMap: 'జిఐఎస్ భూ రికార్డులు (ధరణి)',
      aiAdvisor: 'ఏఐ పాలసీ సలహాదారు',
      policyML: 'ఎంఎల్ ప్రభావ సిమ్యులేటర్',
      stateComparison: 'రాష్ట్ర విధానాల పోలిక',
      dataCatalog: '100+ భూమి డేటాసెట్లు',
      researchPortal: 'పరిశోధనా పత్రాలు',
      openApi: 'ఓపెన్ ఏపీఐ కన్సోల్',
      citizenSearch: 'పట్టాదారు సర్వే నంబర్ సెర్చ్',
    },
    personas: {
      policymaker: 'విధాన నిర్ణేతలు',
      researcher: 'పరిశోధకులు',
      citizen: 'రైతు / భూ యజమాని',
      environmentalist: 'పర్యావరణ పరిశీలకుడు',
    },
    stats: {
      villagesDigitized: 'డిజిటలైజ్డ్ గ్రామాలు (ధరణి)',
      bhuAadhaarGenerated: 'భూ-ఆధార్ జారీ చేయబడింది',
      disputeReduction: 'వివాద పరిష్కార సమయం తగ్గుదల',
      datasetsAvailable: 'జియోస్పేషియల్ డేటాసెట్లు',
      openApiEndpoints: 'సంస్థాగత ఏపీఐలు',
    },
    gis: {
      title: 'కాడాస్ట్రల్ జిఐఎస్ మరియు పట్టాదారు వివరాలు',
      subtitle: 'భూ-ఆధార్‌తో కూడిన సర్వే నంబర్ సరిహద్దుల మ్యాపింగ్',
      parcelDetails: 'పట్టాదారు పాస్‌బుక్ వివరాలు',
      layers: 'మ్యాప్ లేయర్లు',
      inspectParcel: 'వివరాలు చూడటానికి పార్శిల్ ఎంచుకోండి',
      droneSurvey: 'స్వామిత్వ డ్రోన్ సర్వే',
      soilHealth: 'సాయిల్ హెల్త్ ఇండెక్స్',
      disputeRisk: 'ఏఐ వివాద రిస్క్ అంచనా',
    },
    policy: {
      generateBrief: 'సాక్ష్యాల ఆధారిత పాలసీ బ్రీఫ్ రూపొందించండి',
      targetState: 'రాష్ట్రం',
      policyArea: 'సంస్కరణ విభాగం',
      horizon: 'కాలపరిమితి',
      objective: 'లక్ష్యం',
      generating: 'జెమిని ఏఐ విశ్లేషిస్తోంది...',
      downloadBrief: 'పాలసీని డౌన్‌లోడ్ చేయండి',
    },
    ml: {
      title: 'మెషిన్ లెర్నింగ్ పాలసీ ఇంపాక్ట్ ప్రిడిక్టర్',
      subtitle: 'రిజిస్ట్రేషన్ మరియు మ్యుటేషన్ సంస్కరణల ఆర్థిక ప్రభావం',
      runSimulation: 'సిమ్యులేషన్ ప్రారంభించు',
      litigationReduction: 'కోర్టు కేసుల తగ్గుదల',
      revenueShift: 'రాబడి ప్రభావం',
      creditUnlocked: 'రైతులకు బ్యాంక్ రుణాలు',
      tenureSecurity: 'భూ యాజమాన్య భద్రత',
    }
  },
  ta: {
    name: 'தமிழ்',
    flag: '🇮🇳',
    nativeName: 'தமிழ்',
    tagline: 'ஆராய்ச்சி, கொள்கை புத்தாக்கம் மற்றும் சான்று அடிப்படையிலான நில நிர்வாகத்திற்கான தேசிய தளம்',
    nav: {
      overview: 'பொது கண்ணோட்டம்',
      gisMap: 'ஜிஐஎஸ் நில வரைபடம் (பட்டா)',
      aiAdvisor: 'ஏஐ கொள்கை ஆலோசகர்',
      policyML: 'எம்எல் தாக்க உருவகப்படுத்துதல்',
      stateComparison: 'மாநில கொள்கை ஒப்பீடு',
      dataCatalog: '100+ நில தரவுத்தொகுப்புகள்',
      researchPortal: 'ஆராய்ச்சிக் கட்டுரைகள்',
      openApi: 'திறந்தநிலை ஏபிஐ கன்சோல்',
      citizenSearch: 'பட்டா / சிட்டா தேடல்',
    },
    personas: {
      policymaker: 'கொள்கை வகுப்பாளர்கள்',
      researcher: 'கல்வி ஆய்வாளர்கள்',
      citizen: 'நில உரிமையாளர் / குடிமக்கள்',
      environmentalist: 'சுற்றுச்சூழல் ஆய்வாளர்',
    },
    stats: {
      villagesDigitized: 'டிஜிட்டல் மயமாக்கப்பட்ட கிராமங்கள்',
      bhuAadhaarGenerated: 'பூ-ஆதார் (ULPIN) வழங்கப்பட்டது',
      disputeReduction: 'வழக்கு தீர்வு காலக் குறைப்பு',
      datasetsAvailable: 'கிடைக்கக்கூடிய தரவுத்தொகுப்புகள்',
      openApiEndpoints: 'ஏபிஐ அணுகல் புள்ளிகள்',
    },
    gis: {
      title: 'நில அளவை வரைபடம் & பட்டா சிட்டா விவரங்கள்',
      subtitle: 'பூ-ஆதார் மற்றும் எல்லை அளவீட்டுடன் கூடிய துல்லியமான வரைபடம்',
      parcelDetails: 'நில உரிமை ஆவண விவரங்கள்',
      layers: 'வரைபட அடுக்குகள்',
      inspectParcel: 'விவரங்களை அறிய நிலத்தைத் தேர்ந்தெடுக்கவும்',
      droneSurvey: 'சுவாமித்வா ட்ரோன் நில அளவை',
      soilHealth: 'மண் வளக் குறியீடு',
      disputeRisk: 'ஏஐ சர்ச்சை அபாய மதிப்பீடு',
    },
    policy: {
      generateBrief: 'சான்று அடிப்படையிலான கொள்கை வரைவு',
      targetState: 'குறிப்பிட்ட மாநிலம்',
      policyArea: 'சீர்திருத்தத் துறை',
      horizon: 'கால அளவு',
      objective: 'நோக்கம்',
      generating: 'ஜெமினி ஏஐ ஆய்வு செய்கிறது...',
      downloadBrief: 'கொள்கையை பதிவிறக்கு',
    },
    ml: {
      title: 'கொள்கை தாக்க கணிப்பு இயந்திரக் கற்றல்',
      subtitle: 'முத்திரைத்தாள் கட்டணம் மற்றும் டிஜிட்டல்மயமாக்கல் தாக்கங்கள்',
      runSimulation: 'மாதிரி மறு கணக்கீடு',
      litigationReduction: 'நீதிமன்ற வழக்குகள் குறைப்பு',
      revenueShift: 'வருவாய் மாற்றம்',
      creditUnlocked: 'விவசாய கடன் வசதி',
      tenureSecurity: 'நில உரிமை பாதுகாப்பு குறியீடு',
    }
  }
};
